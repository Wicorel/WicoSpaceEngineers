﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System;
using VRage.Collections;
using VRage.Game.Components;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ObjectBuilders.Definitions;
using VRage.Game;
using VRageMath;

namespace IngameScript
{
    partial class Program : MyGridProgram
    {
/*
* Wico craft controller Master Control Script
*
* Control Script for Rovers and Drones and Oribtal craft
* 
* Version 3.0F
* 
* 2.0 Removed many built-in functions to make script room. These functions were duplicated in sub-modules anyway.
* 2.0.1
* 0.2 Remove items from serialize that main control no longer calculates (cargo, battery, etc).
* if simspeed>1.01, assume 1.0 and recalculate.
* 0.3 re-org code sections
* Pass arguments to sub-modules 
* 0.4 (re)integrate power and cargo
* 0.4a process multiple arguments on a command line
* 0.4b check mass change and request reinit including sub-modules.
* 
* 2.1 Code Reorg
* Cache all blocks and grids.  Support for multi-grid constructions.
* !Needs handling for grids connected via connectors..
* 
* .1a Don't force re-init on working projector.
* .1b Add 'brake' command
* Add braking for sleds (added wheelinit)
* 
* 2.2 PB changes in 1.172
* 
* .2a Added modes. Default PB name
* 
* 2.3 Start to add Power information
* 
* .3a Add drills and ejectors to reset motion. Add welders, drills, connectors and grinders to cargo check.
* don't set PB name because it erases settings.. :(
* 
* .3b getblocks fixes when called before gridsinit
* 
* 3.0 remove older items from serialize that are no longer needed
* removed NAV support
* fixed battery maxoutput values
* 
* 3.0a support no remote control blocks. Check for Cryo when getting default controller.
* 3.0b sBanner
* 3.0c caching optimizations
* 3.0d fix connectorsanyconnectors not using localdock
* 3.0e Add Master Reset command
* 3.0f 
* check for grid changes and re-init 
* rotor NOFOLLOW
* ignore projectors with !WCC in name or customdata
* ignore 'cutter' thrusters
* 
* 3.0g Fix problem with allBlockCount being loaded after it has changed
* 
* 3.0H 
* fix problems with docking/undocking and perm re-init
* 
* 05/13: fix GetBlocksContains<T>()
* 
* Handles:
* Master timer for sub-modules
* Calculates ship speed and vectors
* Calculates simspeed
* Configure craft_operation settings
* making sure antenna doesn't get turned off (bug in SE turn off antenna when trying to remotely connect to grid)
* 
* Calculates cargo and power percentages and cargo multiplier and hydro fill and oxy tank fill
 * 
 * Detects grid changes and initiates re-init
 * 
* * 
* MODE_IDLE
* MODE_ATTENTION
* 
* Commands:
* 
* setsimspeed <value>: sets the current simspeed so the calculations can be accurate.
* init: re-init all blocks
* idle : force MODE_IDLE
* coast: turns on/off backward thrusters
* setvaluef <blockname>:<property>:<value>  -> sets specified block's property to specified value
* Example:
*  setvaluef Advanced Rotor:UpperLimit:-24
*
* Need:

* Want:
* 
* menu management for commands (including sub-modules)
* 
* minimize serialized data and make sub-modules pass their own seperately, OR support extra data in state
* 
* common function for 'handle this' combining 'me' grid and an exclusion name check
*
* multi-script handling for modes
* 
* * advanced trigger: only when module handles that mode... (so need mode->module dictionary)
* override base modes?
*
*
*
* WANT:
* setvalueb
* Actions
* Trigger timers on 'events'.
* set antenna name to match mode?
*
*
*
* Note: to fit into 100k Limit, some code has been 'minified'
* Beautify at http://codebeautify.org/csharpviewer
*
*/

string OurName = "Wico Craft";
string moduleName = "Master Control";
string sVersion = "3.0H";

const string sGPSCenter = "Craft Remote Control";

IMyTerminalBlock gpsCenter = null;

Vector3D currentPosition;

//DateTime dtStartTime;
//bool bCalcAssumed = true;
//bool bGotStart = false;

const string velocityFormat = "0.00";

IMyTerminalBlock anchorPosition;

class OurException : Exception
{
    public OurException(string msg) : base("WicoCraft" + ": " + msg) { }
}

Dictionary<string, int> modeCommands = new Dictionary<string, int>();


const string sFastTimer="[WCCT]";
const string sSubModuleTimer = "[WCCS]";

string sBanner = "";
public Program() 
{
	sBanner=OurName + ":" + moduleName+" V"+sVersion + " ";
	Echo(sBanner + "Creator");
	initLogging();
    StatusLog("clear", textLongStatus, true); // only MAIN module should clear long status on init.
	doSubModuleTimerTriggers("[WCCM]"); // try to trigger MAIN timer in case it stopped.
//	if (!Me.CustomName.Contains(moduleName))
//		Me.CustomName = "PB " + OurName+ " "+moduleName;
}

#region MAIN

bool init = false;
bool bWasInit = false;
bool bWantFast = false;

bool bWorkingProjector = false;

double velocityShip;//, velocityForward, velocityUp, velocityLeft;


void Main(string sArgument)
{
	Echo(sBanner + tick());
	bWantFast = false;
	//ProfilerGraph();

	bWorkingProjector = false;
    var list = new List<IMyTerminalBlock>();
    GridTerminalSystem.GetBlocksOfType<IMyProjector>(list, localGridFilter);
    for (int i = 0; i < list.Count; i++)
    {
        if (list[i].IsWorking)
        {
			if (list[i].CustomName.Contains("!WCC") || list[i].CustomData.Contains("!WCC")) continue; // ignore
            Echo("Working local Projector found!");
//            init = false;
//            sInitResults = "";
            bWorkingProjector = true;
        }
    }

    string output = "";

	sPassedArgument = "";
	if (sArgument != "" && sArgument != "timer" || sArgument!="wcct")
	{
		Echo("Arg=" + sArgument);
	}

	double newgridBaseMass = 0;
	IMyTextPanel masstextBlock = getTextBlock("MASS");

	if (anchorPosition != null)
	{
		MyShipMass myMass;
		myMass = ((IMyShipController)anchorPosition).CalculateShipMass();

		StatusLog("clear", masstextBlock);
		StatusLog("BaseMass=" + myMass.BaseMass.ToString(), masstextBlock);
		StatusLog("TotalMass=" + myMass.TotalMass.ToString(), masstextBlock);
		StatusLog("Physicalmass=" + myMass.PhysicalMass.ToString(), masstextBlock);
//		Echo("Physicalmass=" + myMass.PhysicalMass.ToString());
		StatusLog("gridBaseMass=" + gridBaseMass.ToString(), masstextBlock);
		newgridBaseMass = myMass.BaseMass;
		if (myMass.BaseMass == 0)
			Echo("No Mass--Station?");
		if (newgridBaseMass != gridBaseMass && gridBaseMass > 0)
		{
			Echo("MASS CHANGE");
			StatusLog(OurName + ":" + moduleName + ":MASS CHANGE", textLongStatus, true);
		}
	}
	else gridBaseMass=newgridBaseMass = 0;
    if (sArgument == "init"  || (Math.Abs(newgridBaseMass-gridBaseMass)>1 && gridBaseMass>0) || (currentInit==0 && calcGridSystemChanged()))
    {
		StatusLog("INIT or GRID/MASS CHANGE!", masstextBlock);

		Echo("Arg init or grid/mass change!");
        sInitResults = "";
		anchorPosition = null;
        init = false;
        currentInit = 0;
		sPassedArgument = "init";
    }
    Log("clear");

    if (!init)
    {
        if (bWorkingProjector)
        {
            Log("Construction in Progress\nTurn off projector to continue");
            StatusLog("Construction in Progress\nTurn off projector to continue", textPanelReport);
        }
		else
			bWantFast = true;
        doInit();
        bWasInit = true;
    }
    else
    {
	    Deserialize();
		sPassedArgument = sArgument; 

		if (bWasInit)
		{
			StatusLog(DateTime.Now.ToString() + " " + sInitResults, textLongStatus, true);
		}
//        Echo(sInitResults);

        Log(craftOperation());
        IMyTerminalBlock anchorOrientation = gpsCenter;
		/*
        if (anchorOrientation != null)
        {
            Matrix mTmp;
            anchorOrientation.Orientation.GetMatrix(out mTmp);
            mTmp *= -1;
            iForward = new Vector3I(mTmp.Forward);
            iUp = new Vector3I(mTmp.Up);
            iLeft = new Vector3I(mTmp.Left);
        }
		*/
		//        Vector3D mLast = vCurrentPos;
		if (gpsCenter != null)
		{
			vCurrentPos = gpsCenter.GetPosition();
			velocityShip = ((IMyShipController)anchorPosition).GetShipSpeed();
		}

		if (gpsCenter is IMyShipController)
//		if (gpsCenter is IMyRemoteControl)
		{
			Vector3D vNG = ((IMyShipController)gpsCenter).GetNaturalGravity();
//			Vector3D vNG = ((IMyRemoteControl)gpsCenter).GetNaturalGravity();
			double dLength = vNG.Length();
			dGravity = dLength / 9.81;

			if (dGravity > 0)
			{
				double elevation = 0;

				((IMyShipController)gpsCenter).TryGetPlanetElevation(MyPlanetElevation.Surface, out elevation);
				Echo("Elevation=" + elevation.ToString("0.00"));

				double altitude = 0;
				((IMyShipController)gpsCenter).TryGetPlanetElevation(MyPlanetElevation.Sealevel, out altitude);
				Echo("Sea Level=" + altitude.ToString("0.00"));

			}

		}
		else
		{
			dGravity = -1.0;
		}
		
        if (processArguments(sArgument))
            return;


        if(AnyConnectorIsConnected()) output+="Connected";
        else output+="Not Connected";

        if(AnyConnectorIsLocked()) output+="\nLocked";
        else output+=" : Not Locked";
        
        Echo(output);
        Log(output);
		output = "";

        if (bWantFast) Echo("FAST!");

        doCargoCheck();
        Echo("Cargo="+cargopcent.ToString()+"%");
        Echo("Cargo Mult="+cargoMult.ToString());


        batteryCheck(0,false);
		output += "Batteries: #=" + batteryList.Count.ToString();
		if (batteryList.Count > 0 && maxBatteryPower>0)
		{
			output += " : " + (getCurrentBatteryOutput() / maxBatteryPower * 100).ToString("0.00") + "%";
	        output+="\n Storage="+batteryPercentage.ToString()+"%";
		}
		
		Echo(output);
		output = "";

		Echo("Solar: #" + solarList.Count.ToString()+ " "+ currentSolarOutput.ToString("0.00" + "MW"));

		output="Reactors: #" + reactorList.Count.ToString();
		if (reactorList.Count > 0)
		{
			output+=" - " + maxReactorPower.ToString("0.00") + "MW\n";
			float fPer = (float)(getCurrentReactorOutput() / totalMaxPowerOutput * 100);
			output+=" Curr Output=" + getCurrentReactorOutput().ToString("0.00") + "MW"+ " : "+ fPer.ToString("0.00") + "%";
//			Echo("Reactor total usage=" + fPer.ToString("0.00") + "%");
		}
		Echo(output);
		output = "";

		Echo("TotalMaxPower=" + totalMaxPowerOutput.ToString("0.00" + "MW"));

		hydroPercent = tanksFill(iTankHydro);
		oxyPercent = tanksFill(iTankOxygen);
		if (oxyPercent >= 0)
		{
			Echo("O:" + oxyPercent.ToString("000.0%"));
		}
		else Echo("No Oxygen Tanks");

		if (hydroPercent >= 0)
		{
			Echo("H:" + hydroPercent.ToString("000.0%"));
		}
		else Echo("No Hydrogen Tanks");


        if (dGravity >= 0)
        {
            Echo("Grav=" + dGravity.ToString(velocityFormat));
            Log("Planet Gravity " + dGravity.ToString(velocityFormat) + " g");
            Log(progressBar((int)(dGravity / 1.1 * 100)));
        }
        else Log("ERROR: No Remote Control found!");

        doModes();
    }
    Serialize();

	if (anchorPosition == null || SaveFile == null)
	{
		Echo("Cannot use sub-modules; missing controller and/or SaveFile");
	}
	else doSubModuleTimerTriggers();

    if (bWantFast)
        doSubModuleTimerTriggers(sFastTimer);

    bWasInit = false;

    verifyAntenna();

	EchoInstructionPer();

	Echo("Passing:'" + sPassedArgument + "'");

    Echo(craftOperation());

	Echo(sInitResults);
}

void EchoInstructionPer(string sPrefix="")
{
	float fper = 0;
	fper = Runtime.CurrentInstructionCount / (float)Runtime.MaxInstructionCount;
	Echo(sPrefix+"Instructions=" + (fper * 100).ToString() + "%");
}

string[] aTicks = { "-", "\\", "|", "/", "-", "\\", "|", "/" };

int iTick = 99;
string tick()
{
	iTick++;
	if (iTick >= aTicks.Length)
		iTick = 0;
	return aTicks[iTick];

}

#endregion

// Change per module
#region maininit

string sInitResults = "";
int currentInit = 0;

double gridBaseMass = 0;

string doInit()
{

	// initialization of each module goes here:

	// when all initialization is done, set init to true.
	initLogging();

    Log("Init:" + currentInit.ToString());
    double progress = currentInit * 100 / 3; // 3=Number of expected INIT phases.
    string sProgress = progressBar(progress);
    StatusLog(moduleName + sProgress, textPanelReport);
	
    Echo("Init:"+currentInit);
    if (currentInit == 0)
    {
//        StatusLog("clear", textLongStatus, true); // only MAIN module should clear long status on init.
        StatusLog(DateTime.Now.ToString() + " " + OurName + ":" + moduleName + ":INIT", textLongStatus, true);

        /*
        if(!modeCommands.ContainsKey("launchprep")) modeCommands.Add("launchprep", MODE_LAUNCHPREP);
        */
		sInitResults+=	gridsInit();
		initTimers();
        sInitResults += initSerializeCommon();

		Deserialize(); // get info from savefile to avoid blind-rewrite of (our) defaults
    }
    else if (currentInit == 1)
    {
		Deserialize();// get info from savefile to avoid blind-rewrite of (our) defaults

        sInitResults += BlockInit();
		initCargoCheck();
		if (gpsCenter != null)
		{
			anchorPosition = gpsCenter;
			currentPosition = anchorPosition.GetPosition();
		}
		initPower();

		sInitResults += thrustersInit(gpsCenter);
        sInitResults += gyrosetup();
        /*
        }
        else if(currentRun==2)
        {
        */
        sInitResults += wheelsInit(gpsCenter);
        sInitResults += connectorsInit();
		sInitResults += tanksInit();
		sInitResults += drillInit();
		sInitResults += ejectorsInit();


        sInitResults += antennaInit();

//        Serialize();

        autoConfig();
        bWantFast = false;

		if (anchorPosition != null)
		{
			MyShipMass myMass;
			myMass = ((IMyShipController)anchorPosition).CalculateShipMass();

			gridBaseMass = myMass.BaseMass;

			sInitResults += modeOnInit(); // handle mode initializing from load/recompile..

	        init = true; // we are donw

		}
		else
		{
			// we are not complete.  try again..
			currentInit=0;
			bWantFast = false;
			Echo("Missing Required Item; Please add");
			return sInitResults;
		}

    }

    currentInit++;
    if (init) currentInit = 0;

    Log(sInitResults);

    return sInitResults;
}

IMyTextPanel gpsPanel = null;

string BlockInit()
{
    string sInitResults = "";

    List<IMyTerminalBlock> centerSearch = new List<IMyTerminalBlock>();
    GridTerminalSystem.SearchBlocksOfName(sGPSCenter, centerSearch, localGridFilter);
    if (centerSearch.Count == 0)
    {
        centerSearch = GetBlocksContains<IMyRemoteControl>("[NAV]");
        if (centerSearch.Count == 0)
        {
            GridTerminalSystem.GetBlocksOfType<IMyRemoteControl>(centerSearch, localGridFilter);
            if (centerSearch.Count == 0)
            {
                GridTerminalSystem.GetBlocksOfType<IMyCockpit>(centerSearch, localGridFilter);
				//                GridTerminalSystem.GetBlocksOfType<IMyShipController>(centerSearch, localGridFilter);
				int i = 0;
				for(;i<centerSearch.Count;i++)
				{
					Echo("Checking Controller:" + centerSearch[i].CustomName);
					if (centerSearch[i] is IMyCryoChamber)
						continue;
					break;
				}
                if (i >centerSearch.Count)
                {
                    sInitResults += "!!NO valid Controller";
                    Echo("No Controller found");
                }
                else
                {
                    sInitResults += "S";
                    Echo("Using good ship Controller: " + centerSearch[i].CustomName);
                }
            }
            else
            {
                sInitResults += "R";
                Echo("Using First Remote control found: " + centerSearch[0].CustomName);
            }
        }
    }
    else
    {
        sInitResults += "N";
        Echo("Using Named: " + centerSearch[0].CustomName);
    }
	if(centerSearch.Count>0)
	    gpsCenter = centerSearch[0];

    List<IMyTerminalBlock> blocks = new List<IMyTerminalBlock>();
    blocks = GetBlocksContains<IMyTextPanel>("[GPS]");
    if (blocks.Count > 0)
        gpsPanel = blocks[0] as IMyTextPanel;

    return sInitResults;
}

string modeOnInit()
{
    return ">";
}


#endregion

void processTimerCommand()
{
	string output = "";
/*
    if (bCalcAssumed)
    {
        if (bGotStart)
        {
            bCalcAssumed = false;
            bGotStart = false;
            fAssumeElapsed = (float)(DateTime.Now.Subtract(dtStartTime).TotalSeconds * fAssumeSimSpeed);
        }
        else
        {
            dtStartTime = DateTime.Now;
            bGotStart = true;
        }
    }
*/
//    lastPosition = currentPosition;
    currentPosition = anchorPosition.GetPosition();
//    lastVelocity = currentVelocity;

//    currentVelocity = (currentPosition - lastPosition) / Runtime.TimeSinceLastRun.TotalSeconds;// fAssumeElapsed;
  
// currentVelocity = (currentPosition - lastPosition) / ElapsedTime.TotalSeconds;// fAssumeElapsed;

	/*
    center = Me.CubeGrid.GridIntegerToWorld(anchorPosition.Position);
    forward = Me.CubeGrid.GridIntegerToWorld(anchorPosition.Position + iForward) - center;
    up = Me.CubeGrid.GridIntegerToWorld(anchorPosition.Position + iUp) - center;
    left = Me.CubeGrid.GridIntegerToWorld(anchorPosition.Position + iLeft) - center;
    forward.Normalize();
    up.Normalize();
    left.Normalize();
    Echo("assume=" + fAssumeElapsed.ToString("0.000") + " elapsed=" + Runtime.TimeSinceLastRun.TotalSeconds.ToString("0.000"));
    //Echo("assume="+fAssumeElapsed.ToString("0.000")+ " elapsed="+ElapsedTime.TotalSeconds.ToString("0.000"));
    fSimSpeed = fAssumeElapsed / (float)Runtime.TimeSinceLastRun.TotalSeconds;
	/*
	if(fSimSpeed>1.01)
	{
		fAssumeSimSpeed = 1.01f;
		bCalcAssumed = true;
	}
	*/
    // fSimSpeed=fAssumeElapsed/(float)ElapsedTime.TotalSeconds;

	/*
    vectorForward = forward.Project(currentVelocity) * 1 / fSimSpeed;
    vectorUp = up.Project(currentVelocity) * 1 / fSimSpeed;
    vectorLeft = left.Project(currentVelocity) * 1 / fSimSpeed;
    velocityShip = currentVelocity.Length() * 1 / fSimSpeed;
    velocityForward = vectorForward.Length() * 1 / fSimSpeed;
    velocityUp = vectorUp.Length() * 1 / fSimSpeed;
    velocityLeft = vectorLeft.Length() * 1 / fSimSpeed;
	*/
    output += velocityShip.ToString(velocityFormat) + " m/s";
    output += " (" + (velocityShip * 3.6).ToString(velocityFormat) + "km/h)";
//    if (velocityForward > 0.1f) output += "\nF/B:" + velocityForward.ToString(velocityFormat) + " m/s";
//    if (velocityUp > 0.1f) output += "\nU/D:" + velocityUp.ToString(velocityFormat) + " m/s";
//    if (velocityLeft > 0.1f) output += "\nL/R:" + velocityLeft.ToString(velocityFormat) + " m/s";

    // output+="\nElapsed:"+ElapsedTime.TotalSeconds.ToString();
	/*
    output += "\nSimspeed=" + fSimSpeed.ToString(velocityFormat);
    Echo(output);
    output += "\n" + progressBar((int)(fSimSpeed * 100));
	*/
    Log(output);

	/*
    double velocityShip2 = 0;
    output = "";
    velocityShip2 = ((IMyShipController)anchorPosition).GetShipSpeed();
    output += "V2:" + velocityShip2.ToString(velocityFormat) + " m/s";
	output += "Dv=" + (velocityShip2 / velocityShip).ToString("0.00");
    Echo(output);

	velocityShip = velocityShip2;
	*/
}

// multi-arg
#region arguments

bool processArguments(string sArgument)
{
	string[] varArgs = sArgument.Trim().Split(';');

	for (int iArg = 0; iArg < varArgs.Length; iArg++)
	{
		string[] args = varArgs[iArg].Trim().Split(' ');

		if (args[0] == "timer")
		{
			processTimerCommand();

		}
		else if (args[0] == "idle")
			ResetToIdle();
		else if (args[0] == "masterreset")
			MasterReset();
		else if (args[0].ToLower() == "coast")
		{
//	Echo("Coast: backward =" + thrustBackwardList.Count.ToString());
			if (thrustBackwardList.Count > 1)
			{
				blockApplyAction(thrustBackwardList, "OnOff");
//				blockApplyAction(thrustBackwardList, "OnOff_Off");
			}
		}
		else if (args[0] == "setvaluef")
		{
			Echo("SetValueFloat");
			//Miner Advanced Rotor:UpperLimit:-24
			string sArg = "";
			for (int i = 1; i < args.Length; i++)
			{
				sArg += args[i];
				if (i < args.Length - 1)
				{
					sArg += " ";
				}
			}
			string[] cargs = sArg.Trim().Split(':');

			if (cargs.Length < 3)
			{
				Echo("Invalid Args");
				continue;
			}
			IMyTerminalBlock block;
			block = (IMyTerminalBlock)GridTerminalSystem.GetBlockWithName(cargs[0]);
			if (block == null)
			{
				Echo("Block not found:" + cargs[0]);
				continue;
			}
			float fValue = 0;
			bool fOK = float.TryParse(cargs[2].Trim(), out fValue);
			if (!fOK)
			{
				Echo("invalid float value:" + cargs[2]);
				continue;
			}
			Echo("SetValueFloat:" + cargs[0] + " " + cargs[1] + " to:" + fValue.ToString());
			block.SetValueFloat(cargs[1], fValue);
		}
		else if (args[0] == "brake")
		{
			Echo("brake");
			//toggle brake
			if (gpsCenter is IMyShipController)
			{
				IMyShipController msc = gpsCenter as IMyShipController;
				bool bBrake = msc.HandBrake;
				msc.ApplyAction("HandBrake");
			}
			else Echo("No Ship Controller found");

		}
/*
		else if (args[0] == "setsimspeed")
		{
			if (args.Length < 2)
			{
				Echo("setsimspeed:nvalid arg");
				continue;
			}
			float fValue = 0;
			bool fOK = float.TryParse(args[1].Trim(), out fValue);
			if (!fOK)
			{
				Echo("invalid float value:" + args[1]);
				continue;
			}
			fAssumeSimSpeed = fValue;
			bCalcAssumed = true;

		}
*/
		else if (args[0] == "wcct")
		{
			// do nothing special
		}
		else
		{
			int iDMode;
			if (modeCommands.TryGetValue(args[0].ToLower(), out iDMode))
			{
				setMode(iDMode);
			}
			else Echo("Unrecognized Command:" + varArgs[iArg]);
		}
	}
	return false; // keep processing in main
}
#endregion

#region profiler
// Whip's Profiler Graph Code
int count = 1;
int maxSeconds = 60;
StringBuilder profile = new StringBuilder();
void ProfilerGraph()
{
	if (count <= maxSeconds) // assume 1 tick per second.
	{
		Echo("Profiler:Add");
		double timeToRunCode = Runtime.LastRunTimeMs;

		profile.Append(timeToRunCode.ToString()).Append("\n");
		count++;
	}
	else
	{
		Echo("Profiler:DISPLAY");
		var screen = GridTerminalSystem.GetBlockWithName("DEBUG") as IMyTextPanel;
		screen?.WritePublicText(profile.ToString());
		screen?.ShowPublicTextOnScreen();
	}
}

void resetProfiler()
{
	count = 1;
	profile = new StringBuilder();
	var screen = GridTerminalSystem.GetBlockWithName("DEBUG") as IMyTextPanel;
	screen?.WritePublicText("");
	screen?.ShowPublicTextOnScreen();

}
#endregion

#region domodes
void doModes()
{
    Echo("mode=" + iMode.ToString());
/*
    if ((craft_operation & CRAFT_MODE_PET) > 0 && iMode != MODE_PET)
        setLightColor(lightsList, Color.Chocolate);

    if (AnyConnectorIsConnected() && iMode != MODE_LAUNCH && iMode != MODE_RELAUNCH && !((craft_operation & CRAFT_MODE_ORBITAL) > 0) && !((craft_operation & CRAFT_MODE_NAD) > 0))
    {
        setMode(MODE_DOCKED);
    }
	*/
    if (iMode == MODE_IDLE)
        doModeIdle();
	/*
    else if (iMode == MODE_DUMBNAV)
    {
        doModeNav();
    }
	*/
    /*
    else if (iMode == MODE_SLEDMMOVE)
    {
    doModeSledmMove();
    }
    else if (iMode == MODE_SLEDMRAMPD)
    {
    doModeSledmRampD();
    }
    else if (iMode == MODE_SLEDMLEVEL)
    {
    doModeSledmLevel();
    }
    else if (iMode == MODE_SLEDMDRILL)
    {
    doModeSledmDrill();
    }
    else if (iMode == MODE_SLEDMBDRILL)
    {
    doModeSledmBDrill();
    }
    else if (iMode == MODE_DOCKING)
    {
        // doModeDocking();
    }
    else if (iMode == MODE_DOCKED)
    {
        doModeDocked();
    }
    else if (iMode == MODE_LAUNCH)
    {
        // doModeLaunch();
    }
    else if (iMode == MODE_PET)
    {
        doModePet();
    }
	    */

    else if (iMode == MODE_ATTENTION)
    {
        StatusLog("clear", textPanelReport);
        StatusLog(moduleName + ":ATTENTION!", textPanelReport);
        StatusLog(moduleName + ": current_state=" + current_state.ToString(), textPanelReport);
        StatusLog("\nCraft Needs attention", textPanelReport);

    }
}
#endregion

#region modeidle
void ResetToIdle()
{
    StatusLog(DateTime.Now.ToString() + " ACTION: Reset To Idle", textLongStatus, true);
    ResetMotion();
//    if (navCommand != null)
//        if (!(navCommand is IMyTextPanel)) navCommand.CustomName ="NAV: C Wico Craft";
//    if (navStatus != null) navStatus.CustomName=sNavStatus + " Control Reset";
    //bValidPlayerPosition = false;
    setMode(MODE_IDLE);
    if (AnyConnectorIsConnected() && iMode != MODE_LAUNCH && iMode != MODE_RELAUNCH && !((craft_operation & CRAFT_MODE_ORBITAL) > 0) && !((craft_operation & CRAFT_MODE_NAD) > 0))
        setMode(MODE_DOCKED);
}
void doModeIdle()
{
    StatusLog("clear", textPanelReport);
	StatusLog(OurName+":"+moduleName+":Manual Control (idle)",textPanelReport); 

	if (AnyConnectorIsConnected() && iMode != MODE_LAUNCH && iMode != MODE_RELAUNCH && !((craft_operation & CRAFT_MODE_ORBITAL) > 0) && !((craft_operation & CRAFT_MODE_NAD) > 0))
        setMode(MODE_DOCKED);
}
#endregion

void ResetMotion(bool bNoDrills = false)
{
//    if (navEnable != null) blockApplyAction(navEnable, "OnOff_Off"); //navEnable.ApplyAction("OnOff_Off");
    powerDownThrusters(thrustAllList);
    if (gpsCenter is IMyRemoteControl)
	    blockApplyAction(gpsCenter, "AutoPilot_Off");
	if (!bNoDrills) blockApplyAction(drillList, "OnOff_Off");
	gyrosOff();
	blockApplyAction(ejectorList, "OnOff_Off");
}

// Static Code modules

// V3.0 - redo all variables & cleanup
#region serializecommon
const string SAVE_FILE_NAME = "Wico Craft Save";
float savefileversion = 3.00f;
IMyTextPanel SaveFile = null;

// Saved info:
int current_state = 0;

long allBlocksCount = 0;

Vector3D vCurrentPos;
Vector3D vDock;
Vector3D vLaunch1;
Vector3D vHome;
bool bValidDock = false;
bool bValidLaunch1 = false;
bool bValidHome = false;
double dGravity = -2;
int craft_operation = CRAFT_MODE_AUTO;
int currentRun = 0;
string sPassedArgument = "";

// valid vectors
bool bValidInitialContact = false;
bool bValidInitialExit = false;
bool bValidTarget = false;
bool bValidAsteroid = false;
bool bValidNextTarget = false;

// operation flags
bool bAutopilotSet = true;
bool bAutoRelaunch = false;

// 
int iAlertStates = 0;

// time outs
DateTime dtStartShip;
DateTime dtStartCargo;
DateTime dtStartSearch;
DateTime dtStartMining;
DateTime dtLastRan;
DateTime dtStartNav;

// positions
//Vector3D vLastPos;
Vector3D vInitialContact;
Vector3D vInitialExit;
Vector3D vLastContact;
Vector3D vLastExit;
Vector3D vTargetMine;
Vector3D vTargetAsteroid;
Vector3D vCurrentNavTarget;
Vector3D vNextTarget;
Vector3D vExpectedExit;

// detection
int iDetects = 0;
int batterypcthigh = 80;
int batterypctlow = 20;
int batteryPercentage = -1;

int cargopctmin = 5;
int cargopcent = -1;
double cargoMult = -1;

// tanks
double hydroPercent = -1;
double oxyPercent = -1;

double totalMaxPowerOutput = 0;
double maxReactorPower = -1;
double maxSolarPower = -1;
double maxBatteryPower = -1;

string sReceivedMessage = "";

string initSerializeCommon()
{

    string sInitResults = "S";

	SaveFile = null;
    List<IMyTerminalBlock> blocks = new List<IMyTerminalBlock>();
    blocks = GetBlocksNamed<IMyTextPanel>(SAVE_FILE_NAME);

	if (blocks.Count > 1) Echo("Multiple blocks found: \"" + SAVE_FILE_NAME + "\"");
	else if (blocks.Count == 0) Echo("Missing: " + SAVE_FILE_NAME);
	else SaveFile = blocks[0] as IMyTextPanel;

    if (SaveFile == null)
    {
        sInitResults = "-";
        Echo(SAVE_FILE_NAME + " (TextPanel)\n is missing or Named incorrectly. ");
    }
    return sInitResults;
}

bool validSavefile()
{
	return SaveFile != null;
}
string Vector3DToString(Vector3D v)
{
    string s;
    s = v.GetDim(0) + ":" + v.GetDim(1) + ":" + v.GetDim(2);
    return s;
}
bool ParseVector3d(string sVector, out double x, out double y, out double z)
{
    string[] coordinates = sVector.Trim().Split(',');
    if (coordinates.Length < 3)
    {
        coordinates = sVector.Trim().Split(':');
    }
    bool xOk = double.TryParse(coordinates[0].Trim(), out x);
    bool yOk = double.TryParse(coordinates[1].Trim(), out y);
    bool zOk = double.TryParse(coordinates[2].Trim(), out z);
    if (!xOk || !yOk || !zOk)
    {
        return false;
    }
    return true;
}

#endregion

void MasterReset()
{
	ResetToIdle();
	ResetMotion();
	bValidDock = false;
	bValidLaunch1 = false;
	bValidHome = false;
	bValidInitialContact = false;
	bValidInitialExit = false;
	bValidTarget = false;
	bValidAsteroid = false;
	bValidNextTarget = false;

	// operation flags
	bAutopilotSet = true;
	bAutoRelaunch = false;
	iAlertStates = 0;
	iDetects = 0;
	sReceivedMessage = "";
	sLastLoad = "";
	Serialize();
}

//03/29 Optimization: don't write if same as when loaded 
#region mainserialize

// state variables
string sLastLoad = "";

void Serialize()
{
    string sb = "";
    sb += "Wico Craft Controller Saved State Do Not Edit" + "\n";
    sb += savefileversion.ToString("0.00") + "\n";

    sb += iMode.ToString() + "\n";
    sb += current_state.ToString() + "\n";
    sb += currentRun.ToString() + "\n";
	sb += sPassedArgument + "\n";
	sb += iAlertStates.ToString() + "\n";
    sb += dGravity.ToString() + "\n";

	sb += allBlocksCount.ToString() + "\n";

    sb += craft_operation.ToString() + "\n";


    sb += Vector3DToString(vDock) + "\n";
    sb += bValidDock.ToString() + "\n";

    sb += Vector3DToString(vLaunch1) + "\n";
    sb += bValidLaunch1.ToString() + "\n";

    sb += Vector3DToString(vHome) + "\n";
    sb += bValidHome.ToString() + "\n";

	sb += dtStartShip.ToString() + "\n";
	sb += dtStartCargo.ToString() + "\n";
	sb += dtStartSearch.ToString() + "\n";
	sb += dtStartMining.ToString() + "\n";
	sb += dtLastRan.ToString() + "\n";
	sb += dtStartNav.ToString() + "\n";

//	sb += Vector3DToString(vLastPos) + "\n";
	sb += Vector3DToString(vInitialContact) + "\n";
	sb += bValidInitialContact.ToString() + "\n";

	sb += Vector3DToString(vInitialExit) + "\n";
	sb += bValidInitialExit.ToString() + "\n";

	sb += Vector3DToString(vLastContact) + "\n";
	sb += Vector3DToString(vLastExit) + "\n";
	sb += Vector3DToString(vExpectedExit) + "\n";

	sb += Vector3DToString(vTargetMine) + "\n";
	sb += bValidTarget.ToString() + "\n";

	sb += Vector3DToString(vTargetAsteroid) + "\n";
	sb += bValidAsteroid.ToString() + "\n";

	sb += Vector3DToString(vNextTarget) + "\n";
	sb += bValidNextTarget.ToString() + "\n";

	sb += Vector3DToString(vCurrentNavTarget) + "\n";


	sb += bAutopilotSet.ToString() + "\n";
	sb += bAutoRelaunch.ToString() + "\n";
	sb += iDetects.ToString() + "\n";

	sb += batterypcthigh.ToString() + "\n";
	sb += batterypctlow.ToString() + "\n";
	sb += batteryPercentage.ToString() + "\n";

	sb += cargopctmin.ToString() + "\n";
	sb += cargopcent.ToString() + "\n";
	sb += cargoMult.ToString() + "\n";

	sb += hydroPercent.ToString() + "\n";
	sb += oxyPercent.ToString() + "\n";

	sb += totalMaxPowerOutput.ToString() + "\n";
	sb += maxReactorPower.ToString() + "\n";
	sb += maxSolarPower.ToString() + "\n";
	sb += maxBatteryPower.ToString() + "\n";
	sb += sReceivedMessage + "\n";

    if (SaveFile == null)
    {
        Storage = sb.ToString();
        return;
    }
	if (sLastLoad != sb) SaveFile.WritePublicText(sb.ToString(), false);
	else Echo("Not saving: Same");
}

void Deserialize()
{
    double x, y, z;

    string sSave;
    if (SaveFile == null)
        sSave = Storage;
    else
        sSave = SaveFile.GetPublicText();

    if (sSave.Length < 1)
    {
        Echo("Saved information not available");
        return;
    }
	sLastLoad = sSave;

    int i = 1;
    float fVersion = 0;

    string[] atheStorage = sSave.Split('\n');

    // Trick using a "local method", to get the next line from the array `atheStorage`.
    Func<string> getLine = () => {
        return (i >= 0 && atheStorage.Length > i ? atheStorage[i++] : null);
    };

    if (atheStorage.Length < 3)
    {
        // invalid storage
        Storage = "";
        Echo("Invalid Storage");
        return;
    }

    // Simple "local method" which returns false/true, depending on if the
    // given `txt` argument contains the text "True" or "true".
    Func<string, bool> asBool = (txt) => {
        txt = txt.Trim().ToLower();
        return (txt == "True" || txt == "true");
    };

    fVersion = (float)Convert.ToDouble(getLine());

    if (fVersion > savefileversion)
    {
        Echo("Save file version mismatch; it is newer. Check programming blocks.");
        return; // it is something NEWER than us..
    }
	if(fVersion<2.99)
	{
		Echo("Obsolete save. ignoring:"+ fVersion.ToString());
		return;
	}
    iMode = Convert.ToInt32(getLine());
    current_state = Convert.ToInt32(getLine());
    currentRun = Convert.ToInt32(getLine());
	sPassedArgument = getLine();

	iAlertStates = Convert.ToInt32(getLine());

    bool pOK;
    pOK = double.TryParse(getLine(), out dGravity);
	long lJunk;
    pOK = long.TryParse(getLine(), out lJunk);
//    pOK = long.TryParse(getLine(), out allBlocksCount);

    craft_operation = Convert.ToInt32(getLine());

    ParseVector3d(getLine(), out x, out y, out z);
    vDock = new Vector3D(x, y, z);
    bValidDock = asBool(getLine());

    ParseVector3d(getLine(), out x, out y, out z);
    vLaunch1 = new Vector3D(x, y, z);
    bValidLaunch1 = asBool(getLine().ToLower());

    ParseVector3d(getLine(), out x, out y, out z);
    vHome = new Vector3D(x, y, z);
    bValidHome = asBool(getLine());

	dtStartShip = DateTime.Parse(getLine());
	dtStartCargo = DateTime.Parse(getLine());
	dtStartSearch = DateTime.Parse(getLine());
	dtStartMining = DateTime.Parse(getLine());
	dtLastRan = DateTime.Parse(getLine());
	dtStartNav = DateTime.Parse(getLine());
	/*
	ParseVector3d(getLine(), out x, out y, out z);
	vLastPos = new Vector3D(x, y, z);
	*/
	ParseVector3d(getLine(), out x, out y, out z);
	vInitialContact = new Vector3D(x, y, z);
	bValidInitialContact = asBool(getLine());

	ParseVector3d(getLine(), out x, out y, out z);
	vInitialExit = new Vector3D(x, y, z);
	bValidInitialExit = asBool(getLine());

	ParseVector3d(getLine(), out x, out y, out z);
	vLastContact = new Vector3D(x, y, z);

	ParseVector3d(getLine(), out x, out y, out z);
	vLastExit = new Vector3D(x, y, z);

	ParseVector3d(getLine(), out x, out y, out z);
	vExpectedExit = new Vector3D(x, y, z);

	ParseVector3d(getLine(), out x, out y, out z);
	vTargetMine = new Vector3D(x, y, z);
	bValidTarget = asBool(getLine());

	ParseVector3d(getLine(), out x, out y, out z);
	vTargetAsteroid = new Vector3D(x, y, z);
	bValidAsteroid = asBool(getLine());

	ParseVector3d(getLine(), out x, out y, out z);
	vNextTarget = new Vector3D(x, y, z);
	bValidNextTarget = asBool(getLine());

	ParseVector3d(getLine(), out x, out y, out z);
	vCurrentNavTarget = new Vector3D(x, y, z);

	bAutopilotSet = asBool(getLine());
	bAutoRelaunch = asBool(getLine());

	iDetects = Convert.ToInt32(getLine());

	batterypcthigh = Convert.ToInt32(getLine());
	batterypctlow = Convert.ToInt32(getLine());
	batteryPercentage = Convert.ToInt32(getLine());

	cargopctmin = Convert.ToInt32(getLine());
	cargopcent = Convert.ToInt32(getLine());
	cargoMult = Convert.ToDouble(getLine());

	hydroPercent = Convert.ToDouble(getLine());
	oxyPercent = Convert.ToDouble(getLine());

	totalMaxPowerOutput = Convert.ToDouble(getLine());
	maxReactorPower = Convert.ToDouble(getLine());
	maxSolarPower = Convert.ToDouble(getLine());
	maxBatteryPower = Convert.ToDouble(getLine());

	sReceivedMessage = getLine();
}

#endregion

// 12/19 cleanup
#region config

const int CRAFT_MODE_AUTO = 0;
const int CRAFT_MODE_SLED = 2;
const int CRAFT_MODE_ROTOR = 4;
const int CRAFT_MODE_ORBITAL = 32;
const int CRAFT_MODE_ROCKET = 64;
const int CRAFT_MODE_PET = 128;
const int CRAFT_MODE_NAD = 256; // no auto dock
const int CRAFT_MODE_NOAUTOGYRO = 512;
const int CRAFT_MODE_NOPOWERMGMT = 1024;
const int CRAFT_MODE_NOTANK = 2048;
const int CRAFT_MODE_MASK = 0xfff;

//int craft_operation = CRAFT_MODE_AUTO;

string craftOperation()
{
    string sResult = "FLAGS:";
  //  sResult+=craft_operation.ToString();
    if ((craft_operation & CRAFT_MODE_SLED) > 0)
        sResult += "SLED ";
    if ((craft_operation & CRAFT_MODE_ORBITAL) > 0)
        sResult += "ORBITAL ";
    if ((craft_operation & CRAFT_MODE_ROCKET) > 0)
        sResult += "ROCKET ";
    if ((craft_operation & CRAFT_MODE_ROTOR) > 0)
        sResult += "ROTOR ";
    if ((craft_operation & CRAFT_MODE_PET) > 0)
        sResult += "PET ";
    if ((craft_operation & CRAFT_MODE_NAD) > 0)
        sResult += "NAD ";
    if ((craft_operation & CRAFT_MODE_NOAUTOGYRO) > 0)
        sResult += "NO Gyro ";
    if ((craft_operation & CRAFT_MODE_NOTANK) > 0)
        sResult += "No Tank ";
    if ((craft_operation & CRAFT_MODE_NOPOWERMGMT) > 0)
        sResult += "No Power ";
    return sResult;
}
#endregion

#region modes

int iMode = 0;

const int MODE_IDLE = 0;
const int MODE_SEARCH = 1; // old search method..
const int MODE_MINE = 2;
const int MODE_ATTENTION = 3;
const int MODE_WAITINGCARGO = 4;// waiting for cargo to clear before mining.
const int MODE_LAUNCH = 5;
//const int MODE_TARGETTING = 6; // targetting mode to allow remote setting of asteroid target
const int MODE_GOINGTARGET = 7; // going to target asteroid
const int MODE_GOINGHOME = 8;
const int MODE_DOCKING = 9;
const int MODE_DOCKED = 13;

const int MODE_SEARCHORIENT = 10; // orient to entrance location
const int MODE_SEARCHSHIFT = 11; // shift to new lcoation
const int MODE_SEARCHVERIFY = 12; // verify asteroid in front (then mine)'
const int MODE_RELAUNCH = 14;
const int MODE_SEARCHCORE = 15;// go to the center of asteroid and search from the core.


const int MODE_HOVER = 16;
const int MODE_LAND = 17;
const int MODE_MOVE = 18;
const int MODE_LANDED = 19;

const int MODE_DUMBNAV = 20;

const int MODE_SLEDMMOVE = 21;
const int MODE_SLEDMRAMPD = 22;
const int MODE_SLEDMLEVEL = 23;
const int MODE_SLEDMDRILL = 24;
const int MODE_SLEDMBDRILL = 25;

const int MODE_LAUNCHPREP = 26; // oribital launch prep
const int MODE_INSPACE = 27; // now in space (no gravity)
const int MODE_ORBITALLAUNCH = 28;

const int MODE_ARRIVEDTARGET=29; // we have arrived at target
const int MODE_ARRIVEDHOME=30; // we have arrived at home

const int MODE_UNDERCONSTRUCTION = 31;

const int MODE_PET = 111; // pet that follows the player

void setMode(int newMode)
{
    if (iMode == newMode) return;
    iMode = newMode;
    current_state = 0;
}

#endregion

// need to use me.CustomData
#region autoconfig
void autoConfig()
{
    craft_operation = CRAFT_MODE_AUTO;
    if ((craft_operation & CRAFT_MODE_MASK) == CRAFT_MODE_AUTO)
    {
        int iThrustModes = 0;

        if (Me.CustomName.ToLower().Contains("nad"))
            craft_operation |= CRAFT_MODE_NAD;
        if (Me.CustomName.ToLower().Contains("rotor"))
            craft_operation |= CRAFT_MODE_ROTOR;
        else if (/*wheelList.Count>0 || */ Me.CustomName.ToLower().Contains("sled"))
            craft_operation |= CRAFT_MODE_SLED;

        if (ionThrustCount > 0)
        {
            iThrustModes++;
        }
        if (hydroThrustCount > 0)
        {
            iThrustModes++;
        }
        if (atmoThrustCount > 0)
        {
            iThrustModes++;
        }

        if (iThrustModes > 1 || Me.CustomName.ToLower().Contains("orbital"))
            craft_operation |= CRAFT_MODE_ORBITAL;
        if (Me.CustomName.ToLower().Contains("rocket"))
            craft_operation |= CRAFT_MODE_ROCKET;
        if (Me.CustomName.ToLower().Contains("pet"))
            craft_operation |= CRAFT_MODE_PET;
        if (Me.CustomName.ToLower().Contains("noautogyro"))
            craft_operation |= CRAFT_MODE_NOAUTOGYRO;
        if (Me.CustomName.ToLower().Contains("nopower"))
            craft_operation |= CRAFT_MODE_NOPOWERMGMT;
        if (Me.CustomName.ToLower().Contains("notank"))
            craft_operation |= CRAFT_MODE_NOTANK;
    }
}
#endregion

// 04/08: NOFOLLOW for rotors (for print heads)
// 03/10 moved definition of allBlocksCount to serialize. Fixed piston localgrid
// check customdata for contains 01/07/17
// add allBlocksCount
// cross-grid 12/19
// split grids/blocks
#region getgrids
List<IMyTerminalBlock> gtsAllBlocks = new List<IMyTerminalBlock>();

List <IMyCubeGrid> localGrids =new List<IMyCubeGrid>();
List <IMyCubeGrid> remoteGrids =new List<IMyCubeGrid>();
List <IMyCubeGrid> dockedGrids =new List<IMyCubeGrid>();
List <IMyCubeGrid> allGrids =new List<IMyCubeGrid>();


bool calcGridSystemChanged()
{
	List<IMyTerminalBlock> gtsTestBlocks = new List<IMyTerminalBlock>();
	GridTerminalSystem.GetBlocksOfType < IMyTerminalBlock > (gtsTestBlocks);
	if (allBlocksCount != gtsTestBlocks.Count)
	{
		return true;
	}
	return false;
}
string gridsInit()
{
	gtsAllBlocks.Clear();
	allGrids.Clear();
	localGrids.Clear();
	remoteGrids.Clear();
	dockedGrids.Clear();

	GridTerminalSystem.GetBlocksOfType < IMyTerminalBlock > (gtsAllBlocks);
	allBlocksCount = gtsAllBlocks.Count;

	foreach (var block in gtsAllBlocks)
	{
		var grid = block.CubeGrid;
		if (!allGrids.Contains(grid))
		{
			allGrids.Add(grid);
		}
	}
	addGridToLocal(Me.CubeGrid); // the PB is known to be local..  Start there.

	foreach (var grid in allGrids)
	{
		if (localGrids.Contains(grid))
			continue; // already in the list;
		bool bConnected = false;

		List<IMyShipConnector> gridConnectors = new List<IMyShipConnector>();
		GridTerminalSystem.GetBlocksOfType<IMyShipConnector>(gridConnectors, (x => x.CubeGrid == grid));
		foreach (var connector in gridConnectors)
		{
			if (connector.Status==MyShipConnectorStatus.Connected)
			{
				if(localGrids.Contains(connector.OtherConnector.CubeGrid) || remoteGrids.Contains(connector.OtherConnector.CubeGrid))
				{ // if the other connector is connected to an already known grid, ignore it.
					continue;
				}
				if (localGrids.Contains(connector.OtherConnector.CubeGrid))
					bConnected = true;
				else bConnected = false;
			}
		}

		if(bConnected)
		{
			if (!dockedGrids.Contains(grid))
			{
				dockedGrids.Add(grid);
			}

		}
		if (!remoteGrids.Contains(grid))
		{
			remoteGrids.Add(grid);
		}
	}


	string s = "";
	s += "B"+gtsAllBlocks.Count.ToString();
	s += "G"+allGrids.Count.ToString();
	s += "L"+localGrids.Count.ToString();
	s += "D"+dockedGrids.Count.ToString();
	s += "R"+remoteGrids.Count.ToString();

	Echo("Found " + gtsAllBlocks.Count.ToString() + " Blocks");
	Echo("Found " + allGrids.Count.ToString() + " Grids");
	Echo("Found " + localGrids.Count.ToString() + " Local Grids");
	for (int i = 0; i < localGrids.Count; i++) Echo("|"+localGrids[i].CustomName);
	Echo("Found " + dockedGrids.Count.ToString() + " Docked Grids");
	for (int i = 0; i < dockedGrids.Count; i++) Echo("|"+dockedGrids[i].CustomName);
	Echo("Found " + remoteGrids.Count.ToString() + " Remote Grids");
	for (int i = 0; i < remoteGrids.Count; i++) Echo("|"+remoteGrids[i].CustomName);

	return s;
}

void addGridToLocal(IMyCubeGrid grid)
{
	if (grid == null) return;
	if (!localGrids.Contains(grid))
	{
		localGrids.Add(grid);

		addRotorsConnectedToGrids(grid);
		addPistonsConnectedToGrids(grid);
		addGridsToLocalRotors(grid);
		addGridsToLocalPistons(grid);
	}
}

void addRotorsConnectedToGrids(IMyCubeGrid grid)
{ 
	List<IMyMotorStator> gridRotors = new List<IMyMotorStator>();
	GridTerminalSystem.GetBlocksOfType<IMyMotorStator>(gridRotors, (x => x.TopGrid == grid));
	foreach (var rotor in gridRotors)
	{
		if (rotor.CustomName.Contains("NOFOLLOW") || rotor.CustomData.Contains("NOFOLLOW"))
			continue;
		addGridToLocal(rotor.CubeGrid);
	}
	List<IMyMotorAdvancedStator> gridARotors = new List<IMyMotorAdvancedStator>();
	GridTerminalSystem.GetBlocksOfType<IMyMotorAdvancedStator>(gridARotors, (x => x.TopGrid == grid));
	foreach (var rotor in gridARotors)
	{
		if (rotor.CustomName.Contains("NOFOLLOW") || rotor.CustomData.Contains("NOFOLLOW"))
			continue;
		addGridToLocal(rotor.CubeGrid);
	}
}

void addPistonsConnectedToGrids(IMyCubeGrid grid)
{ 
	List<IMyPistonBase> gridPistons = new List<IMyPistonBase>();
	GridTerminalSystem.GetBlocksOfType<IMyPistonBase>(gridPistons, (x => x.TopGrid == grid));
	foreach (var piston in gridPistons)
	{
		addGridToLocal(piston.CubeGrid);
	}
}

void addGridsToLocalRotors(IMyCubeGrid grid)
{
	List<IMyMotorStator> gridRotors = new List<IMyMotorStator>();
	GridTerminalSystem.GetBlocksOfType<IMyMotorStator>(gridRotors, (x => x.CubeGrid == grid));
	foreach (var rotor in gridRotors)
	{
		if (rotor.CustomName.Contains("NOFOLLOW") || rotor.CustomData.Contains("NOFOLLOW"))
			continue;
		IMyCubeGrid topGrid = rotor.TopGrid;
		if (topGrid != null && topGrid!=grid)
		{
			addGridToLocal(topGrid);
		}
	}
	gridRotors.Clear();

	List<IMyMotorAdvancedStator> gridARotors = new List<IMyMotorAdvancedStator>();
	GridTerminalSystem.GetBlocksOfType<IMyMotorAdvancedStator>(gridARotors, (x => x.CubeGrid == grid));
	foreach (var rotor in gridARotors)
	{
		if (rotor.CustomName.Contains("NOFOLLOW") || rotor.CustomData.Contains("NOFOLLOW"))
			continue;
		IMyCubeGrid topGrid = rotor.TopGrid;
		if (topGrid != null && topGrid!=grid)
		{
			addGridToLocal(topGrid);
		}
	}

}
void addGridsToLocalPistons(IMyCubeGrid grid)
{
	List<IMyPistonBase> gridPistons = new List<IMyPistonBase>();
	GridTerminalSystem.GetBlocksOfType<IMyPistonBase>(gridPistons, (x => x.CubeGrid == grid));
	foreach (var piston in gridPistons)
	{
		IMyCubeGrid topGrid = piston.TopGrid;
//		if (topGrid != null) Echo(piston.CustomName + " Connected to grid:" + topGrid.CustomName);
		if (topGrid != null && topGrid != grid)
		{
			if (!localGrids.Contains(topGrid))
			{
				addGridToLocal(topGrid);
			}
		}
	}
}

List <IMyCubeGrid> calculateLocalGrids()
{
	if (localGrids.Count < 1)
	{
		gridsInit();
	}
	return localGrids;
}
List <IMyCubeGrid> calculateDockedGrids()
{
	if (localGrids.Count < 1)
	{
		gridsInit();
	}
	return dockedGrids;
}

bool localGridFilter(IMyTerminalBlock block)
{
	return calculateLocalGrids().Contains(block.CubeGrid);
}

bool dockedGridFilter(IMyTerminalBlock block)
{
	List <IMyCubeGrid> g=calculateDockedGrids();
	if(g==null) return false;
	return g.Contains(block.CubeGrid);
}

#endregion

// 05/12: Fix bug in GetBlocksContains()
// 03/09: Init grids on get if needed
// 02/25: use cached block list from grids
// split code into grids and blocks
#region getblocks
IMyTerminalBlock get_block(string name)
{
    IMyTerminalBlock block;
    block = (IMyTerminalBlock)GridTerminalSystem.GetBlockWithName(name);
    if (block == null)
        throw new Exception(name + " Not Found"); return block;
}

public List<IMyTerminalBlock> GetTargetBlocks<T>(ref List<IMyTerminalBlock> Output, string Keyword = null) where T : class
{
    if (gtsAllBlocks.Count < 1) gridsInit();
    Output.Clear();
    for (int e = 0; e < gtsAllBlocks.Count; e++)
    {
        if (localGridFilter(gtsAllBlocks[e]) && gtsAllBlocks[e] is T && ((Keyword == null) || (Keyword != null && gtsAllBlocks[e].CustomName.StartsWith(Keyword))))
        {
            Output.Add(gtsAllBlocks[e]);
        }
    }
    return Output;
}
public List<IMyTerminalBlock> GetTargetBlocks<T>(string Keyword = null) where T : class
{
    List<IMyTerminalBlock> Output = new List<IMyTerminalBlock>();
    GetTargetBlocks<T>(ref Output, Keyword);
    return Output;
}
public List<IMyTerminalBlock> GetBlocksContains<T>(string Keyword = null) where T : class
{
    if (gtsAllBlocks.Count < 1) gridsInit();
    List<IMyTerminalBlock> Output = new List<IMyTerminalBlock>();
    for (int e = 0; e < gtsAllBlocks.Count; e++)
    {
        if (localGridFilter(gtsAllBlocks[e]) && gtsAllBlocks[e] is T && Keyword != null && (gtsAllBlocks[e].CustomName.Contains(Keyword) || gtsAllBlocks[e].CustomData.Contains(Keyword)))
        {
            Output.Add(gtsAllBlocks[e]);
        }
    }
    return Output;
}
public List<IMyTerminalBlock> GetBlocksNamed<T>(string Keyword = null) where T : class
{
    if (gtsAllBlocks.Count < 1) gridsInit();
    List<IMyTerminalBlock> Output = new List<IMyTerminalBlock>();
    for (int e = 0; e < gtsAllBlocks.Count; e++)
    {
        if (localGridFilter(gtsAllBlocks[e]) && gtsAllBlocks[e] is T && Keyword != null && gtsAllBlocks[e].CustomName == Keyword)
        {
            Output.Add(gtsAllBlocks[e]);
        }
    }
    return Output;
}

#endregion


#region blockactions
void groupApplyAction(string sGroup, string sAction)
{
    List<IMyBlockGroup> groups = new List<IMyBlockGroup>();
	GridTerminalSystem.GetBlockGroups(groups);
	for (int groupIndex = 0; groupIndex < groups.Count; groupIndex++)
    {
        if (groups[groupIndex].Name == sGroup)
        { //var blocks=null;
            List<IMyTerminalBlock> blocks = null;
            groups[groupIndex].GetBlocks(blocks, localGridFilter);

            //blocks=groups[groupIndex].Blocks;
            List<IMyTerminalBlock> theBlocks = blocks;
			for (int iIndex = 0; iIndex < theBlocks.Count; iIndex++)
            {
				theBlocks[iIndex].ApplyAction(sAction);
			}
            return;
        }
    }
    return;
}
void listSetValueFloat(List<IMyTerminalBlock> theBlocks, string sProperty, float fValue)
{
    for (int iIndex = 0; iIndex < theBlocks.Count; iIndex++)
    {
        if (theBlocks[iIndex].CubeGrid == Me.CubeGrid)
            theBlocks[iIndex].SetValueFloat(sProperty, fValue);
    }
    return;
}
void blockApplyAction(string sBlock, string sAction)
{ List<IMyTerminalBlock> blocks = new List<IMyTerminalBlock>(); blocks = GetBlocksNamed<IMyTerminalBlock>(sBlock); blockApplyAction(blocks, sAction); }
void blockApplyAction(IMyTerminalBlock sBlock, string sAction)
{ ITerminalAction ita; ita = sBlock.GetActionWithName(sAction); if (ita != null) ita.Apply(sBlock); else Echo("Unsupported action:" + sAction); }
void blockApplyAction(List<IMyTerminalBlock> lBlock, string sAction)
{
    if (lBlock.Count > 0)
    {
        for (int i = 0; i < lBlock.Count; i++)
        {
			ITerminalAction ita;
			ita = lBlock[i].GetActionWithName(sAction);
			if (ita != null)
				ita.Apply(lBlock[i]);
			else
				Echo("Unsupported action:" + sAction);
		}
    }
}
#endregion

// 2/7: 180
// 1/24 Update to support no RC.
// with vDir
// 12/24 added forward
// fix RC init
// !NAV to not use a gyro. Tested in space.. 
#region Autogyro 
// Originally from: http://forums.keenswh.com/threads/aligning-ship-to-planet-gravity.7373513/#post-1286885461 

// uses: gpsCenter from other code as the designated remote or ship controller

double CTRL_COEFF = 0.5; 
int LIMIT_GYROS = 3; // max number of gyros to use to align craft. Leaving some available allows for player control to continue during auto-align 
IMyShipController rc; 
List < IMyGyro > gyros;

float minAngleRad=0.01f; // how tight to maintain aim Lower is tighter. 

bool GyroMain(string argument)
{
	if (rc == null)
		gyrosetup();
//	Echo("GyroMain(" + argument + ")");

	if (rc is IMyRemoteControl)
	{
		Vector3D grav = (rc as IMyRemoteControl).GetNaturalGravity();
		return GyroMain(argument, grav, gpsCenter);
	}
	else
	{
		Echo("No Remote Control for gravity");
	}

	return true;
} 

bool GyroMain(string argument, Vector3D vDirection, IMyTerminalBlock gyroControlPoint)  
{
	bool bAligned=true; 
	if (rc == null) 
		gyrosetup();
//	Echo("GyroMain(" + argument + ",VECTOR3D)");	 
	Matrix or; 
	gyroControlPoint.Orientation.GetMatrix(out or); 

	Vector3D down;
	if (argument.ToLower().Contains("rocket"))
		down = or.Backward;
	else if (argument.ToLower().Contains("backward"))
		down = or.Backward;
	else if (argument.ToLower().Contains("forward"))
		down = or.Forward;
	else
		down = or.Down; 
 
	vDirection.Normalize();

	for (int i = 0; i < gyros.Count; ++i)  
	{ 
		var g = gyros[i];
		g.Orientation.GetMatrix(out or); 
		var localDown = Vector3D.Transform(down, MatrixD.Transpose(or)); 
		var localGrav = Vector3D.Transform(vDirection, MatrixD.Transpose(g.WorldMatrix.GetOrientation()));

		//Since the gyro ui lies, we are not trying to control yaw,pitch,roll but rather we 
		//need a rotation vector (axis around which to rotate) 
		var rot = Vector3D.Cross(localDown, localGrav);
		double dot2 = Vector3D.Dot(localDown, localGrav);
		double ang = rot.Length(); 
		ang = Math.Atan2(ang, Math.Sqrt(Math.Max(0.0, 1.0 - ang * ang)));
		if (dot2 < 0) ang += Math.PI; // compensate for >+/-90
		if (ang < minAngleRad)  
		{ // close enough 
			g.SetValueBool("Override", false); 
			continue; 
		} 
//		Echo("Auto-Level:Off level: "+(ang*180.0/3.14).ToString()+"deg"); 
 
		double ctrl_vel = g.GetMaximum < float > ("Yaw") * (ang / Math.PI) * CTRL_COEFF; 
		ctrl_vel = Math.Min(g.GetMaximum < float > ("Yaw"), ctrl_vel); 
		ctrl_vel = Math.Max(0.01, ctrl_vel); 
		rot.Normalize(); 
		rot *= ctrl_vel;
		float pitch = (float)rot.GetDim(0);
		g.SetValueFloat("Pitch", pitch);

		float yaw = -(float)rot.GetDim(1);
		g.SetValueFloat("Yaw", yaw);

		float roll = -(float)rot.GetDim(2);
		g.SetValueFloat("Roll", roll); 
//		g.SetValueFloat("Power", 1.0f); 
		g.SetValueBool("Override", true);
		bAligned=false; 
	} 
	return bAligned; 
}

 
string gyrosetup()  
{ 
	var l = new List < IMyTerminalBlock > ();
	rc = gpsCenter as IMyShipController;

	if (rc == null)  
	{ 
		if (l.Count < 1) return "No RC!"; 
		rc = (IMyRemoteControl) l[0]; 
	}
	gyrosOff(); // turn off any working gyros from previous runs
	// NOTE: Uses grid of controller, not ME, nor localgridfilter
	GridTerminalSystem.GetBlocksOfType < IMyGyro > (l, x => x.CubeGrid == gpsCenter.CubeGrid); 
	var l2 = new List < IMyTerminalBlock > ();
	for (int i = 0; i < l.Count; i++)
	{
		if (l[i].CustomName.Contains("!NAV") || l[i].CustomData.Contains("!NAV"))
		{
			continue;
		}
		l2.Add(l[i]);
	}
	gyros = l2.ConvertAll(x => (IMyGyro)x);
	if (gyros.Count > LIMIT_GYROS) 
		gyros.RemoveRange(LIMIT_GYROS, gyros.Count - LIMIT_GYROS); 
	return "G" + gyros.Count.ToString("00"); 
} 
void gyrosOff() 
{
	if (gyros != null)
	{
		for (int i = 0; i < gyros.Count; ++i)
		{
			gyros[i].SetValueBool("Override", false);
		}
	} 
}
#endregion


// 2/25: Performance: only check blocks once, re-check on init.
// use cached blocks 12/xx
#region logging

string sLongStatus = "Wico Craft Log";
string sTextPanelReport = "Craft Report";
IMyTextPanel statustextblock = null;
IMyTextPanel textLongStatus = null;
IMyTextPanel textPanelReport = null;
bool bLoggingInit = false;

void initLogging()
{
	statustextblock = getTextStatusBlock(true);
	textLongStatus = getTextBlock(sLongStatus);;
	textPanelReport = getTextBlock(sTextPanelReport);
	bLoggingInit = true;
}

IMyTextPanel getTextBlock(string stheName)
{
    IMyTextPanel textblock = null;
	List<IMyTerminalBlock> blocks = new List<IMyTerminalBlock>();
	blocks = GetBlocksNamed<IMyTerminalBlock>(stheName);
	if (blocks.Count < 1)
    {
        blocks = GetBlocksContains<IMyTextPanel>(stheName);
		if (blocks.Count > 0)
            textblock = blocks[0] as IMyTextPanel;
    }
    else if (blocks.Count > 1)
        throw new OurException("Multiple status blocks found: \"" + stheName + "\"");
    else textblock = blocks[0] as IMyTextPanel;
	return textblock;
}

IMyTextPanel getTextStatusBlock(bool force_update = false)
{
	if ((statustextblock != null || bLoggingInit) && !force_update ) return statustextblock;
	statustextblock = getTextBlock(OurName + " Status");
	return statustextblock;
}
void StatusLog(string text, IMyTextPanel block, bool bReverse = false)
{
    if (block == null) return;
    if (text.Equals("clear"))
    {
        block.WritePublicText("");
    }
    else
    {
        if (bReverse)
        {
            string oldtext = block.GetPublicText();
            block.WritePublicText(text + "\n" + oldtext);
        }
        else block.WritePublicText(text + "\n", true);
        // block.WritePublicTitle(DateTime.Now.ToString());
    }
    block.ShowTextureOnScreen();
    block.ShowPublicTextOnScreen();
}

void Log(string text)
{
	StatusLog(text, getTextStatusBlock());
}
string progressBar(double percent)
{
	int barSize = 75;
	if (percent < 0) percent = 0;
	int filledBarSize = (int)(percent * barSize) / 100;
	if (filledBarSize > barSize) filledBarSize = barSize;
	string sResult = "[" + new String('|', filledBarSize) + new String('\'', barSize - filledBarSize) + "]";
	return sResult;
}

#endregion

//03/27: Added caching for performance
#region triggers
Dictionary<string, List<IMyTerminalBlock>> dTimers = new Dictionary<string, List<IMyTerminalBlock>>();

void initTimers()
{
	dTimers.Clear();
}

void doSubModuleTimerTriggers(string sKeyword = "[WCCS]")
{
	List<IMyTerminalBlock> blocks = new List<IMyTerminalBlock>();

	IMyTimerBlock theTriggerTimer = null;

	if (dTimers.ContainsKey(sKeyword))
	{
		blocks = dTimers[sKeyword];
	}
	else
	{
		blocks = GetBlocksContains<IMyTerminalBlock>(sKeyword);
		dTimers.Add(sKeyword, blocks);
	}

	for (int i = 0; i < blocks.Count; i++)
    {
        theTriggerTimer = blocks[i] as IMyTimerBlock;
        if (theTriggerTimer != null)
        {
//            Echo("dSMT:" + blocks[i].CustomName);
            theTriggerTimer.ApplyAction("TriggerNow");
        }
    }

}

#endregion

// 4/8: Add cutter exclusion
#region thrusters
List<IMyTerminalBlock> thrustForwardList = new List<IMyTerminalBlock>();
List<IMyTerminalBlock> thrustBackwardList = new List<IMyTerminalBlock>();
List<IMyTerminalBlock> thrustDownList = new List<IMyTerminalBlock>();
List<IMyTerminalBlock> thrustUpList = new List<IMyTerminalBlock>();
List<IMyTerminalBlock> thrustLeftList = new List<IMyTerminalBlock>();
List<IMyTerminalBlock> thrustRightList = new List<IMyTerminalBlock>();

double thrustForward = 0;
double thrustBackward = 0;
double thrustDown = 0;
double thrustUp = 0;
double thrustLeft = 0;
double thrustRight = 0;

int ionThrustCount = 0;
int hydroThrustCount = 0;
int atmoThrustCount = 0;
const int thrustatmo = 1;
const int thrusthydro = 2;
const int thrustion = 4;
const int thrustAll = 0xff;
List<IMyTerminalBlock> thrustAllList = new List<IMyTerminalBlock>();
readonly Matrix identityMatrix = new Matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);

string thrustersInit(IMyTerminalBlock orientationBlock)
{
	thrustForwardList.Clear();
	thrustBackwardList.Clear();
	thrustDownList.Clear();
	thrustUpList.Clear();
	thrustLeftList.Clear();
	thrustRightList.Clear();
	thrustAllList.Clear();

	if (orientationBlock == null) return "No Orientation Block";

//	GridTerminalSystem.GetBlocksOfType<IMyThrust>(thrustAllList, localGridFilter);
	List<IMyTerminalBlock> thrustLocal = new List<IMyTerminalBlock>();

	GridTerminalSystem.GetBlocksOfType<IMyThrust>(thrustLocal, localGridFilter);
	for(int i=0;i<thrustLocal.Count;i++)
	{
		if (thrustLocal[i].CustomName.ToLower().Contains("cutter") || thrustLocal[i].CustomData.ToLower().Contains("cutter"))
			continue;
		thrustAllList.Add(thrustLocal[i]);
	}


	Matrix fromGridToReference;
	orientationBlock.Orientation.GetMatrix(out fromGridToReference);
	Matrix.Transpose(ref fromGridToReference, out fromGridToReference);

	thrustForward = 0;
	thrustBackward = 0;
	thrustDown = 0;
	thrustUp = 0;
	thrustLeft = 0;
	thrustRight = 0;

	for (int i = 0; i < thrustAllList.Count; ++i)
	{
		IMyThrust thruster = thrustAllList[i] as IMyThrust;
		Matrix fromThrusterToGrid;
		thruster.Orientation.GetMatrix(out fromThrusterToGrid);
		Vector3 accelerationDirection = Vector3.Transform(fromThrusterToGrid.Backward, fromGridToReference);
		int iThrustType = thrusterType(thrustAllList[i]);
		if (iThrustType == thrustatmo)
			atmoThrustCount++;
		else if (iThrustType == thrusthydro)
			hydroThrustCount++;
		else if (iThrustType == thrustion)
			ionThrustCount++;
		if (accelerationDirection == identityMatrix.Left)
		{
			thrustLeft += maxThrust((IMyThrust)thrustAllList[i]);
			thrustLeftList.Add(thrustAllList[i]);
		}
		else if (accelerationDirection == identityMatrix.Right)
		{
			thrustRight += maxThrust((IMyThrust)thrustAllList[i]);
			thrustRightList.Add(thrustAllList[i]);
		}
		else if (accelerationDirection == identityMatrix.Backward)
		{
			thrustBackward += maxThrust((IMyThrust)thrustAllList[i]);
			thrustBackwardList.Add(thrustAllList[i]);
		}
		else if (accelerationDirection == identityMatrix.Forward)
		{
			thrustForward += maxThrust((IMyThrust)thrustAllList[i]);
			thrustForwardList.Add(thrustAllList[i]);
		}
		else if (accelerationDirection == identityMatrix.Up)
		{
			thrustUp += maxThrust((IMyThrust)thrustAllList[i]);
			thrustUpList.Add(thrustAllList[i]);
		}
		else if (accelerationDirection == identityMatrix.Down)
		{
			thrustDown += maxThrust((IMyThrust)thrustAllList[i]);
			thrustDownList.Add(thrustAllList[i]);
		}
	}

	string s;
	s = ">";
	s += "F" + thrustForwardList.Count.ToString("00");
	s += "B" + thrustBackwardList.Count.ToString("00");
	s += "D" + thrustDownList.Count.ToString("00");
	s += "U" + thrustUpList.Count.ToString("00");
	s += "L" + thrustLeftList.Count.ToString("00");
	s += "R" + thrustRightList.Count.ToString("00");
	s += "<";
	return s;
}
int thrusterType(IMyTerminalBlock theBlock)
{
	if (theBlock is IMyThrust)
	{
		if (theBlock.BlockDefinition.SubtypeId.Contains("Atmo"))
			return thrustatmo;
		else if (theBlock.BlockDefinition.SubtypeId.Contains("Hydro"))
			return thrusthydro;
		else return thrustion;
	}
	return 0;
}

double maxThrust(IMyThrust thruster)
{

//	StatusLog(thruster.CustomName+":"+thruster.BlockDefinition.SubtypeId,textLongStatus,true);
	double max = 0;

 	if (thruster.GetValueFloat("Override") > 1.0001)
	{
		max = thruster.CurrentThrust * 100 / thruster.GetValueFloat("Override");
	}
	
	else
	{
//		Echo("mT:Not Override");
		max = thruster.MaxThrust;
		if (max == 0)
		{

			string s = thruster.BlockDefinition.SubtypeId;
			if (s.Contains("LargeBlock"))
			{
				if (s.Contains("LargeAtmo"))
				{
					max = 5400000;
				}
				else if (s.Contains("SmallAtmo"))
				{
					max = 420000;
				}
				else if (s.Contains("LargeHydro"))
				{
					max = 6000000;
				}
				else if (s.Contains("SmallHydro"))
				{
					max = 900000;
				}
				else if (s.Contains("LargeThrust"))
				{
					max = 3600000;
				}
				else if (s.Contains("SmallThrust"))
				{
					max = 288000;
				}
				else
				{
					StatusLog("Unknown Thrust Type", textLongStatus, true);

					Echo("Unknown Thrust Type");
				}
			}
			else
			{
				//StatusLog("Small grid",textLongStatus,true);
				if (s.Contains("LargeAtmo"))
				{
					max = 408000;
				}
				else if (s.Contains("SmallAtmo"))
				{
					max = 80000;
				}
				else if (s.Contains("LargeHydro"))
				{
					max = 400000;
				}
				else if (s.Contains("SmallHydro"))
				{
					max = 82000;
				}
				else if (s.Contains("LargeThrust"))
				{
					max = 144000;
				}
				else if (s.Contains("SmallThrust"))
				{
					max = 12000;
				}
				else
				{
					StatusLog("Unknown Thrust Type", textLongStatus, true);

					Echo("Unknown Thrust Type");
				}

			}
		}
	}
	return max;
}

double calculateMaxThrust(List<IMyTerminalBlock> thrusters, int iTypes = thrustAll)
{
	double thrust = 0;
//	Echo("cMT:" + iTypes.ToString() + ":"+ thrusters.Count);
	for (int thrusterIndex = 0; thrusterIndex < thrusters.Count; thrusterIndex++)
	{
		int iThrusterType = thrusterType(thrusters[thrusterIndex]);
//		Echo(thrusterIndex.ToString() + ":" + thrusters[thrusterIndex].CustomName + ":" + iThrusterType.ToString());
		if ((iThrusterType & iTypes) > 0)
		{
//			Echo("My Type");
			IMyThrust thruster = thrusters[thrusterIndex] as IMyThrust;
			double dThrust = maxThrust(thruster);
			/*
			if (dGravity < 1.0)
			{
				Echo("NO ATMO");
				if (iThrusterType == thrustatmo)
					dThrust = 0;
			}
			else
			{
				if (iThrusterType == thrustion)
				{
					double dAdjust = 1;
					dAdjust = (1 - dGravity);
					if (dAdjust < .3) dAdjust = .3;
					dThrust = dThrust * dAdjust;
				}
			}
			*/
			thrust += dThrust;
//			Echo("thisthrust=" + dThrust.ToString("N0"));
		}
//		else Echo("NOT My Type");
	}

	return thrust;
}

bool calculateHoverThrust(List<IMyTerminalBlock> thrusters, out float atmoPercent, out float hydroPercent, out float ionPercent)
{
	atmoPercent = 0;
	hydroPercent = 0;
	ionPercent = 0;
	double ionThrust = 0;// calculateMaxThrust(thrusters, thrustion);
	double atmoThrust = calculateMaxThrust(thrusters, thrustatmo);
	double hydroThrust = calculateMaxThrust(thrusters, thrusthydro);

	MyShipMass myMass;
	myMass = ((IMyShipController)gpsCenter).CalculateShipMass();
	double hoverthrust = 0;
	hoverthrust = myMass.TotalMass * dGravity * 9.810;

	Echo("hoverthrust=" + hoverthrust.ToString("N0"));


	if (atmoThrust > 0)
	{
		if (atmoThrust < hoverthrust)
		{
			atmoPercent = 100;
			hoverthrust -= atmoThrust;
		}
		else
		{
			atmoPercent = (float)(hoverthrust / atmoThrust * 100);
			if (atmoPercent > 0)
				hoverthrust -= (atmoThrust * atmoPercent / 100);
		}
	}
//	Echo("ALeft over thrust=" + hoverthrust.ToString("N0"));

	if (ionThrust > 0 && hoverthrust > 0)
	{
		if (ionThrust < hoverthrust)
		{
			ionPercent = 100;
			hoverthrust -= ionThrust;
		}
		else
		{
			ionPercent = (float)(hoverthrust / ionThrust * 100);
			if (ionPercent > 0)
				hoverthrust -= ((ionThrust * ionPercent) / 100);
		}
	}
//	Echo("ILeft over thrust=" + hoverthrust.ToString("N0"));

	if (hydroThrust > 0 && hoverthrust > 0)
	{
		if (hydroThrust < hoverthrust)
		{
			hydroPercent = 100;
			hoverthrust -= hydroThrust;
		}
		else
		{
			hydroPercent = (float)(hoverthrust / hydroThrust * 100);
			if (hydroPercent > 0)
				hoverthrust -= ((hydroThrust * hydroPercent) / 100); ;
		}
	}
//	Echo("Atmo=" + ((atmoThrust * atmoPercent) / 100).ToString("N0"));
//	Echo("ion=" + ((ionThrust * ionPercent) / 100).ToString("N0"));
//	Echo("hydro=" + ((hydroThrust * hydroPercent) / 100).ToString("N0"));
//	Echo("Left over thrust=" + hoverthrust.ToString("N0"));
	if (hoverthrust > 0) return false;
	return true;
}

List<IMyTerminalBlock> findThrusters(string sGroup)
{
	List<IMyTerminalBlock> lthrusters = new List<IMyTerminalBlock>();
	List<IMyBlockGroup> groups = new List<IMyBlockGroup>();
	GridTerminalSystem.GetBlockGroups(groups);
	for (int groupIndex = 0; groupIndex < groups.Count; groupIndex++)
	{
		if (groups[groupIndex].Name == sGroup)
		{
			List<IMyTerminalBlock> thrusters = null;
			groups[groupIndex].GetBlocks(thrusters, localGridFilter);
			for (int thrusterIndex = 0; thrusterIndex < thrusters.Count; thrusterIndex++)
			{
				lthrusters.Add(thrusters[thrusterIndex]);
			}
			break;
		}
	}
	return lthrusters;
}
int powerUpThrusters(List<IMyTerminalBlock> thrusters, float fPower, int iTypes = thrustAll)
{
	int iCount = 0;
	if (fPower > 100) fPower = 100;
	for (int thrusterIndex = 0; thrusterIndex < thrusters.Count; thrusterIndex++)
	{
		int iThrusterType = thrusterType(thrusters[thrusterIndex]);
		if ((iThrusterType & iTypes) > 0)
		{
			IMyThrust thruster = thrusters[thrusterIndex] as IMyThrust;
			float maxThrust = thruster.GetMaximum<float>("Override");
			if (!thruster.IsWorking)
			{
				thruster.ApplyAction("OnOff_On");
			}
			iCount += 1;
			thruster.SetValueFloat("Override", maxThrust * (fPower / 100.0f));
		}
	}
	return iCount;
}
int powerUpThrusters(List<IMyTerminalBlock> thrusters, int iPower = 100, int iTypes = thrustAll)
{
	return powerUpThrusters(thrusters, (float)iPower, iTypes);

}
bool powerUpThrusters(string sFThrust, int iPower = 100, int iTypes = thrustAll)
{
	if (iPower > 100) iPower = 100;
	List<IMyBlockGroup> groups = new List<IMyBlockGroup>();
	GridTerminalSystem.GetBlockGroups(groups);
	for (int groupIndex = 0; groupIndex < groups.Count; groupIndex++)
	{
		if (groups[groupIndex].Name == sFThrust)
		{
			List<IMyTerminalBlock> thrusters = null;
			groups[groupIndex].GetBlocks(thrusters, localGridFilter);
			return (powerUpThrusters(thrusters, iPower, iTypes) > 0);
		}
	}
	return false;
}
int powerDownThrusters(List<IMyTerminalBlock> thrusters, int iTypes = thrustAll, bool bForceOff = false)
{
	int iCount = 0;
	for (int thrusterIndex = 0; thrusterIndex < thrusters.Count; thrusterIndex++)
	{
		int iThrusterType = thrusterType(thrusters[thrusterIndex]);
		if ((iThrusterType & iTypes) > 0)
		{
			iCount++;
			IMyThrust thruster = thrusters[thrusterIndex] as IMyThrust;
			thruster.SetValueFloat("Override", 0);
			if (thruster.IsWorking && bForceOff)
				thruster.ApplyAction("OnOff_Off");
			else if (!thruster.IsWorking && !bForceOff)
				thruster.ApplyAction("OnOff_On");
		}
	}
	return iCount;
}
bool powerDownThrusters(string sFThrust)
{
	List<IMyBlockGroup> groups = new List<IMyBlockGroup>(); GridTerminalSystem.GetBlockGroups(groups); for (int groupIndex = 0; groupIndex < groups.Count; groupIndex++)
	{
		if (groups[groupIndex].Name == sFThrust)
		{
			List<IMyTerminalBlock> thrusters = null;
			groups[groupIndex].GetBlocks(thrusters, localGridFilter); return (powerDownThrusters(thrusters) > 0);
		}
	}
	return false;
}
bool powerUpThrusters()
{ return (powerUpThrusters(thrustForwardList) > 0); }
bool powerDownThrusters()
{ return (powerDownThrusters(thrustForwardList) > 0); }
double currentOverrideThrusters(List<IMyTerminalBlock> theBlocks, int iTypes = thrustAll)
{
	for (int i = 0; i < theBlocks.Count; i++)
	{
		int iThrusterType = thrusterType(theBlocks[i]); if ((iThrusterType & iTypes) > 0 && theBlocks[i].IsWorking)
		{ IMyThrust thruster = theBlocks[i] as IMyThrust; float maxThrust = thruster.GetMaximum<float>("Override"); if (maxThrust > 0) return (double)thruster.ThrustOverride / maxThrust * 100; }
	}
	return 0;
}
bool areThrustersOn(List<IMyTerminalBlock> theBlocks, int iTypes = thrustAll)
{
	for (int i = 0; i < theBlocks.Count; i++)
	{
		int iThrusterType = thrusterType(theBlocks[i]); if ((iThrusterType & iTypes) > 0 && theBlocks[i].IsWorking)
		{ return true; }
	}
	return false;
}

#endregion

//03/30 Fix connectany to use localdock
//03/27 cache optimizations
// starts looking for "[DOCK]"
// also looks for [BASE] and excludes those
// 01/07/2017
// 01/10 added other connector
// 01/24 1.172 PB API changes
#region connectors
List<IMyTerminalBlock> localConnectors = new List<IMyTerminalBlock>();
List<IMyTerminalBlock> localDockConnectors = new List<IMyTerminalBlock>();
List<IMyTerminalBlock> localBaseConnectors = new List<IMyTerminalBlock>();

bool bConnectorsInit = false;

string connectorsInit()
{
	bConnectorsInit = false;
	localConnectors.Clear();
	localDockConnectors.Clear();
	localBaseConnectors.Clear();
	getLocalConnectors();
	return "CL" + localConnectors.Count.ToString()+ "CD"+localDockConnectors.Count.ToString()+ "CB"+localBaseConnectors.Count.ToString();
}

void getLocalConnectors()
{
	if (localConnectors.Count < 1 && !bConnectorsInit) localConnectors = GetTargetBlocks<IMyShipConnector>();

	if (localDockConnectors.Count < 1 && !bConnectorsInit) localDockConnectors = GetBlocksContains<IMyShipConnector>("[DOCK]");
	if (localDockConnectors.Count < 1 && !bConnectorsInit) localDockConnectors = localConnectors;
	if (localBaseConnectors.Count < 1 && !bConnectorsInit) localBaseConnectors = GetBlocksContains<IMyShipConnector>("[BASE]");
	bConnectorsInit = true;
	return;
}
bool AnyConnectorIsLocked()
{
	getLocalConnectors();

	for (int i = 0; i < localDockConnectors.Count; i++)
	{
		IMyShipConnector sc = localDockConnectors[i] as IMyShipConnector;
		if (sc.Status == MyShipConnectorStatus.Connectable)
//		if (sc.IsLocked)
			return true;
	}
	return false;
}

bool AnyConnectorIsConnected()
{
	getLocalConnectors();

	for (int i = 0; i < localDockConnectors.Count; i++)
	{
		IMyShipConnector sc = localDockConnectors[i] as IMyShipConnector;
		if (sc.Status == MyShipConnectorStatus.Connected)
		{
			IMyShipConnector sco = sc.OtherConnector;
			if (sco.CubeGrid == sc.CubeGrid)
			{
				//Echo("Locked-but connected to 'us'");
				continue;
			}
			else return true;
		}
	}
	return false;
}

IMyTerminalBlock getDockingConnector() // maybe pass in prefered orientation?
{ // dumb mode for now.
	if(localDockConnectors.Count>0)
	{
	Echo("Found local Connector");
		return localDockConnectors[0];
	}
Echo("NO local connectors");
	return null;
}

IMyTerminalBlock getConnectedConnector()
{
	getLocalConnectors();

	for (int i = 0; i < localDockConnectors.Count; i++)
	{
		IMyShipConnector sc = localDockConnectors[i] as IMyShipConnector;
		if (sc.Status == MyShipConnectorStatus.Connected)
//		if (sc.Status == MyShipConnectorStatus.Connected)
		{
			IMyShipConnector sco = sc.OtherConnector;
			if (sco.CubeGrid == sc.CubeGrid)
			{
				//Echo("Locked-but connected to 'us'");
				continue;
			}
			else return sc.OtherConnector;
		}
	}
	return null;

}

void ConnectAnyConnectors(bool bConnect = true, string sAction = "")
{
	getLocalConnectors();
	Echo("CCA:"+ localDockConnectors.Count);
	for (int i = 0; i < localDockConnectors.Count; i++)
	{
		IMyShipConnector sc = localDockConnectors[i] as IMyShipConnector;
		if (sc.Status == MyShipConnectorStatus.Connected)
		{
			IMyShipConnector sco = sc.OtherConnector;
			if (sco.CubeGrid == sc.CubeGrid)
			{
				//Echo("Locked-but connected to 'us'");
				continue; // skip it.
			}
		}
		if (bConnect)
		{
			if (sc.Status == MyShipConnectorStatus.Connectable) sc.ApplyAction("SwitchLock");
		}
		else
		{
			if (sc.Status == MyShipConnectorStatus.Connected) sc.ApplyAction("SwitchLock");
		}

		if (sAction != "")
		{
			ITerminalAction ita;
			ita = sc.GetActionWithName(sAction);
			if (ita != null) ita.Apply(sc);
		}

	}
	return;
}

#endregion

//20170107 Added sled and rear/front
#region wheels

List < IMyTerminalBlock > wheelList = new List < IMyTerminalBlock > ();
List < IMyTerminalBlock > wheelSledList = new List < IMyTerminalBlock > ();
List < IMyTerminalBlock > wheelRearSledList = new List < IMyTerminalBlock > ();
List < IMyTerminalBlock > wheelFrontSledList = new List < IMyTerminalBlock > ();


string wheelsInit(IMyTerminalBlock orientationBlock)
{
	wheelList.Clear();
	wheelSledList.Clear();
	wheelRearSledList.Clear();
	wheelFrontSledList.Clear();


	GridTerminalSystem.GetBlocksOfType < IMyMotorSuspension > (wheelList, localGridFilter);

	Matrix fromGridToReference;
	orientationBlock.Orientation.GetMatrix(out fromGridToReference);
	Matrix.Transpose(ref fromGridToReference, out fromGridToReference);
	
	for(int i=0; i<wheelList.Count; i++)
	{
		if(wheelList[i].CustomName.Contains("[SLED]") || wheelList[i].CustomData.Contains("[SLED]"))
		{
			wheelSledList.Add(wheelList[i]);
			if(wheelList[i].CustomName.Contains("[REAR]") || wheelList[i].CustomData.Contains("[FRONT]"))
			{
				wheelRearSledList.Add(wheelList[i]);
			}
			if (wheelList[i].CustomName.Contains("[FRONT]") || wheelList[i].CustomData.Contains("[FRONT]"))
			{
				wheelFrontSledList.Add(wheelList[i]);
			}
		}
	}
    return "W" + wheelList.Count.ToString("0") +"WS" + wheelSledList.Count.ToString("0")+"SR" + wheelRearSledList.Count.ToString("0")+"SF" + wheelFrontSledList.Count.ToString("0");
}

#endregion

#region Antenna

List<IMyTerminalBlock> antennaList = new List<IMyTerminalBlock>();

string antennaInit()
{
	antennaList.Clear();
    GridTerminalSystem.GetBlocksOfType<IMyRadioAntenna>(antennaList, localGridFilter);

    return "A" + antennaList.Count.ToString("0");
}

//// Verify antenna stays on to fix keen bug where antenna will turn itself off when you try to remote control
void verifyAntenna()
{
    blockApplyAction(antennaList, "OnOff_On");
}
#endregion

#region powerproducer

public static class PowerProducer
{

    /// <summary>
    /// Getting power level from its position in DetailedInfo.
    /// The order of power levels changes from block to block, so each block type needs functions.
    /// </summary>
    #region Positional

    private const byte
    Enum_BatteryLine_MaxOutput = 1,
    Enum_BatteryLine_MaxRequiredInput = 2,
    Enum_BatteryLine_MaxStored = 3,
    Enum_BatteryLine_CurrentInput = 4,
    Enum_BatteryLine_CurrentOutput = 5,
    Enum_BatteryLine_CurrentStored = 6;


    private const byte
    Enum_ReactorLine_MaxOutput = 1,
    Enum_ReactorLine_CurrentOutput = 2;

    private const byte
    Enum_SolarPanelLine_MaxOutput = 1,
    Enum_SolarPanelLine_CurrentOutput = 2;

    private const byte
    Enum_GravityLine_MaxRequiredInput = 1,
    Enum_GravityLine_CurrentInput = 2;

    private static readonly char[] wordBreak = { ' ' };


    public static bool GetMaxOutput(IMyBatteryBlock battery, out float value)
    { return GetPowerFromInfo(battery, Enum_BatteryLine_MaxOutput, out value); }

    public static bool GetMaxRequiredInput(IMyBatteryBlock battery, out float value)
    { return GetPowerFromInfo(battery, Enum_BatteryLine_MaxRequiredInput, out value); }

    public static bool GetCurrentInput(IMyBatteryBlock battery, out float value)
    { return GetPowerFromInfo(battery, Enum_BatteryLine_CurrentInput, out value); }

    public static bool GetCurrentOutput(IMyBatteryBlock battery, out float value)
    { return GetPowerFromInfo(battery, Enum_BatteryLine_CurrentOutput, out value); }

    public static bool GetMaxStored(IMyBatteryBlock battery, out float value)
    { return GetPowerFromInfo(battery, Enum_BatteryLine_MaxStored, out value); }

    public static bool GetCurrentStored(IMyBatteryBlock battery, out float value)
    { return GetPowerFromInfo(battery, Enum_BatteryLine_CurrentStored, out value); }


    public static bool GetMaxOutput(IMyReactor reactor, out float value)
    { return GetPowerFromInfo(reactor, Enum_ReactorLine_MaxOutput, out value); }

    public static bool GetCurrentOutput(IMyReactor reactor, out float value)
    { return GetPowerFromInfo(reactor, Enum_ReactorLine_CurrentOutput, out value); }


    public static bool GetMaxOutput(IMySolarPanel panel, out float value)
    { return GetPowerFromInfo(panel, Enum_SolarPanelLine_MaxOutput, out value); }

    public static bool GetCurrentOutput(IMySolarPanel panel, out float value)
    { return GetPowerFromInfo(panel, Enum_SolarPanelLine_CurrentOutput, out value); }


    public static bool GetMaxRequiredInput(IMyGravityGeneratorBase gravity, out float value)
    { return GetPowerFromInfo(gravity, Enum_GravityLine_MaxRequiredInput, out value); }

    public static bool GetCurrentInput(IMyGravityGeneratorBase gravity, out float value)
    { return GetPowerFromInfo(gravity, Enum_GravityLine_CurrentInput, out value); }


    private static bool GetPowerFromInfo(IMyTerminalBlock block, byte lineNumber, out float value)
    {
        value = -1;
        float multiplier;

        string[] lines = block.DetailedInfo.Split('\n');
        string[] words = lines[lineNumber].Split(wordBreak, StringSplitOptions.RemoveEmptyEntries);

        if (words.Length < 2
        || !float.TryParse(words[words.Length - 2], out value)
        || !getMultiplier('W', words[words.Length - 1], out multiplier))
            return false;

        value *= multiplier;
        value /= 1000 * 1000f;

        return true;
    }

    #endregion

    /// <summary>
    /// Getting power level from DetailedInfo using regular expressions.
    /// No localization.
    /// </summary>
    #region Regular Expressions
    private static readonly System.Text.RegularExpressions.Regex CurrentInput = new System.Text.RegularExpressions.Regex(@"(\nCurrent Input:)\s+(-?\d+\.?\d*)\s+(\w+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase); private static readonly System.Text.RegularExpressions.Regex CurrentOutput = new System.Text.RegularExpressions.Regex(@"(\nCurrent Output:)\s+(-?\d+\.?\d*)\s+(\w+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase); private static readonly System.Text.RegularExpressions.Regex MaxPowerOutput = new System.Text.RegularExpressions.Regex(@"(\nMax Output:)\s+(-?\d+\.?\d*)\s+(\w+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase); private static readonly System.Text.RegularExpressions.Regex MaxRequiredInput = new System.Text.RegularExpressions.Regex(@"(\nMax Required Input:)\s+(-?\d+\.?\d*)\s+(\w+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase); private static readonly System.Text.RegularExpressions.Regex RequiredInput = new System.Text.RegularExpressions.Regex(@"(\nRequired Input:)\s+(-?\d+\.?\d*)\s+(\w+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase); public static bool GetCurrentInput(IMyTerminalBlock block, out float value)
    { return GetPowerFromInfo(block, CurrentInput, out value); }
    public static bool GetCurrentOutput(IMyTerminalBlock block, out float value)
    { return GetPowerFromInfo(block, CurrentOutput, out value); }
    public static bool GetMaxPowerOutput(IMyTerminalBlock block, out float value)
    { return GetPowerFromInfo(block, MaxPowerOutput, out value); }
    public static bool GetMaxRequiredInput(IMyTerminalBlock block, out float value)
    { return GetPowerFromInfo(block, MaxRequiredInput, out value); }
    public static bool GetRequiredInput(IMyTerminalBlock block, out float value)
    { return GetPowerFromInfo(block, RequiredInput, out value); }
	private static bool GetPowerFromInfo(IMyTerminalBlock block, System.Text.RegularExpressions.Regex regex, out float value)
	{
		value = -1; float multiplier; System.Text.RegularExpressions.Match match = regex.Match(block.DetailedInfo); if (!match.Success || !float.TryParse(match.Groups[2].ToString(), out value) || !getMultiplier('W', match.Groups[3].ToString(), out multiplier))
			return false; value *= multiplier; return true;
	}
	#endregion
	public const string depleted_in = "Fully depleted in:"; public const string recharged_in = "Fully recharged in:"; private const float
    k = 1000f, M = k * k, G = k * M, T = k * G, m = 0.001f; public static bool IsRecharging(IMyBatteryBlock battery)
    { return battery.DetailedInfo.Contains(recharged_in); }
    public static bool IsDepleting(IMyBatteryBlock battery)
    { return battery.DetailedInfo.Contains(depleted_in); }
    private static bool getMultiplier(char unit, string expr, out float result)
    {
        result = 0; char firstChar = expr[0]; if (firstChar == unit)
        { result = 1; return true; }
        if (expr[1] != unit)
            return false; float k = 1000; if (firstChar == 'k')
            result = k;
        else if (firstChar == 'M')
            result = M;
        else if (firstChar == 'G')
            result = G;
        else if (firstChar == 'T')
            result = T;
        else if (firstChar == 'm')
            result = m; return result != 0;
    }
}

#endregion

#region power

void initPower()
{
	totalMaxPowerOutput = 0;
	Echo("Init power");
	initReactors();
	initSolars();
	initBatteries();
	if (maxReactorPower > 0)
		totalMaxPowerOutput += maxReactorPower;
//	if (maxSolarPower > 0)
//		totalMaxPowerOutput += maxSolarPower;
	if (maxBatteryPower > 0)
		totalMaxPowerOutput += maxBatteryPower;
}

#endregion

#region reactors
List<IMyTerminalBlock> reactorList = new List<IMyTerminalBlock>();

void initReactors()
{
	reactorList.Clear();
	maxReactorPower = -1;
    GridTerminalSystem.GetBlocksOfType<IMyReactor>(reactorList, localGridFilter);
	if (reactorList.Count > 0)
		maxReactorPower = 0;
	foreach(var tb in reactorList)
	{
		IMyReactor r = tb as IMyReactor;
		maxReactorPower += r.MaxOutput;
	}
}

double getCurrentReactorOutput()
{
	double output = 0;
	foreach(var tb in reactorList)
	{
		IMyReactor r = tb as IMyReactor;
		output += r.CurrentOutput;
	}
	return output;
}

#endregion

#region solar
List<IMyTerminalBlock> solarList = new List<IMyTerminalBlock>();

float currentSolarOutput = 0;

void initSolars()
{
	solarList.Clear();
	maxSolarPower = -1;
    GridTerminalSystem.GetBlocksOfType<IMySolarPanel>(solarList, localGridFilter);
	calcCurrentSolar();
}

void calcCurrentSolar()
{
	if (solarList.Count > 0)
		maxSolarPower = 0;

	currentSolarOutput= 0;

//	Echo("Solars:");
	foreach(var tb in solarList)
	{
		IMySolarPanel r = tb as IMySolarPanel;
//		Echo(r.CustomName + " Max=" + r.MaxOutput.ToString("0.000") + " c=" + r.CurrentOutput.ToString("0.000"));
		maxSolarPower += r.MaxOutput;
		currentSolarOutput += r.CurrentOutput;
	}

}

#endregion

#region batterycheck

List<IMyTerminalBlock> batteryList = new List<IMyTerminalBlock>();

bool isRechargeSet(IMyTerminalBlock block)
{
    if (block is IMyBatteryBlock)
    {
        IMyBatteryBlock myb = block as IMyBatteryBlock;
		return myb.OnlyRecharge;// myb.GetValueBool("Recharge");
    }
    else return false;
}
bool isDischargeSet(IMyTerminalBlock block)
{
    if (block is IMyBatteryBlock)
    {
        IMyBatteryBlock myb = block as IMyBatteryBlock;
		return myb.OnlyDischarge;// GetValueBool("Discharge");
    }
    else return false;
}
bool isRecharging(IMyTerminalBlock block)
{
    if (block is IMyBatteryBlock)
    {
        IMyBatteryBlock myb = block as IMyBatteryBlock;
		return myb.IsCharging;// PowerProducer.IsRecharging(myb);
    }
    else return false;
}
void initBatteries()
{
	batteryList.Clear();
	batteryPercentage = -1;
	maxBatteryPower = -1;
    GridTerminalSystem.GetBlocksOfType<IMyBatteryBlock>(batteryList, localGridFilter);
	if (batteryList.Count > 0)
		maxBatteryPower = 0;
	foreach(var tb in batteryList)
	{
		float output = 0;
		IMyBatteryBlock r = tb as IMyBatteryBlock;

		PowerProducer.GetMaxOutput(r, out output);
//		output = r.MaxOutput;

		maxBatteryPower += output;
	}
}

double getCurrentBatteryOutput()
{
	double output = 0;
	foreach(var tb in batteryList)
	{
		IMyBatteryBlock r = tb as IMyBatteryBlock;
		output += r.CurrentOutput;
	}
	return output;
}

bool batteryCheck(int targetMax, bool bEcho = true, IMyTextPanel textBlock = null, bool bProgress = false)
{
    float totalCapacity = 0;
    float totalCharge = 0;
    bool bFoundRecharging = false;
    float f;

	if (batteryList.Count < 1) initBatteries();
	if (batteryList.Count < 1) return false;

    batteryPercentage = 0;
    for (int ib = 0; ib < batteryList.Count; ib++)
    {
        float charge = 0;
        float capacity = 0;
        int percentthisbattery = 100;
        IMyBatteryBlock b;
        b = batteryList[ib] as IMyBatteryBlock;
		f = b.MaxStoredPower;
        capacity += f;
        totalCapacity += f;
		f = b.CurrentStoredPower;
        charge += f;
        totalCharge += f;
        if (capacity > 0)
        {
            f = ((charge * 100) / capacity);
            f = (float)Math.Round(f, 0);
            percentthisbattery = (int)f;
        }
        string s;
        s = "";
        if (isRechargeSet(batteryList[ib])) s += "R";
        else if (isDischargeSet(batteryList[ib])) s += "D";
        else s += "a";
        float fPower;
		fPower = b.CurrentInput;
        if (fPower > 0)
            s += "+";
        else s += " ";
		fPower = b.CurrentOutput;
        if (fPower > 0)
            s += "-";
        else s += " ";
        s += percentthisbattery + "%";
        s += ":" + batteryList[ib].CustomName;
        if (bEcho) Echo(s);
        if (textBlock != null) StatusLog(s, textBlock);
        if (bProgress)
        {
            s = progressBar(percentthisbattery);
            if (textBlock != null) StatusLog(s, textBlock);
        }
        if (isRechargeSet(batteryList[ib]))
        {
            if (percentthisbattery < targetMax)
                bFoundRecharging = true;
            else if (percentthisbattery > 99)
                batteryList[ib].ApplyAction("Recharge");
        }
        if (!isRechargeSet(batteryList[ib]) && percentthisbattery < targetMax && !bFoundRecharging)
        {
            Echo("Turning on Recharge for " + batteryList[ib].CustomName);
            batteryList[ib].ApplyAction("Recharge");
            bFoundRecharging = true;
        }
    }
    if (totalCapacity > 0)
    {
        f = ((totalCharge * 100) / totalCapacity);
        f = (float)Math.Round(f, 0);
        batteryPercentage = (int)f;
    }
    else
        batteryPercentage = -1;
    return bFoundRecharging;
}
void batteryDischargeSet(bool bEcho = false)
{
    Echo(batteryList.Count + " Batteries");
    for (int i = 0; i < batteryList.Count; i++)
    {
        string s = batteryList[i].CustomName + ": ";
        if (isRechargeSet(batteryList[i]))
        {
            s += "RECHARGE/";
            batteryList[i].ApplyAction("Recharge");
        }
        else s += "NOTRECHARGE/";
        if (isDischargeSet(batteryList[i]))
        {
            s += "DISCHARGE";
        }
        else
        {
            s += "NOTDISCHARGE";
            batteryList[i].ApplyAction("Discharge");
        }
        if (bEcho) Echo(s);
    }
}
#endregion

// 1/24: SE 1.172
#region cargocheck

List<IMyTerminalBlock> lContainers = null;
//List < IMyTerminalBlock > lDrills = new List < IMyTerminalBlock > ();

bool bCreative = false;

double totalCurrent = 0.0; // volume

void initCargoCheck()
{
    List<IMyTerminalBlock> grid = new List<IMyTerminalBlock>();

    if(lContainers == null) lContainers = new List<IMyTerminalBlock>();
	else lContainers.Clear();

    GridTerminalSystem.GetBlocksOfType<IMyCargoContainer>(grid, localGridFilter);

    lContainers.AddRange(grid);

	grid.Clear();
	GridTerminalSystem.GetBlocksOfType<IMyShipDrill>(grid, localGridFilter);
    lContainers.AddRange(grid);

	grid.Clear();
	GridTerminalSystem.GetBlocksOfType<IMyShipConnector>(grid, localGridFilter);
	lContainers.AddRange(grid);

	grid.Clear();
	GridTerminalSystem.GetBlocksOfType<IMyShipWelder>(grid, localGridFilter);
	lContainers.AddRange(grid);

	grid.Clear();
	GridTerminalSystem.GetBlocksOfType<IMyShipGrinder>(grid, localGridFilter);
	lContainers.AddRange(grid);

	cargopcent = -1;
	cargoMult = -1;
}

void doCargoCheck()
{
    if (lContainers == null)
        initCargoCheck();

	if (lContainers.Count < 1)
	{
		// No cargo containers found.
		cargopcent = -1;
		cargoMult = -1;
		return;
	}
    totalCurrent = 0.0;
    double totalMax = 0.0;
    double ratio = 0;

	for (int i = 0; i < lContainers.Count; i++)
    {
		totalMax += cargoCapacity(lContainers[i]);
    }
//	Echo("totalMax=" + totalMax.ToString("0.00"));
    if (totalMax > 0)
    {
        ratio = (totalCurrent / totalMax) * 100;
    }
    else
    {
        ratio = 100;
    }
    //Echo("ratio="+ratio.ToString());
    cargopcent = (int)ratio;

}

double cargoCapacity(IMyTerminalBlock theContainer)
{
	double capacity = -1;

	var count = theContainer.InventoryCount;
	for (var invcount = 0; invcount < count; invcount++)
	{
		IMyInventory inv = theContainer.GetInventory(invcount);

		if (inv != null) // null means, no items in inventory.
		{
			totalCurrent += (double)inv.CurrentVolume;

			if ((double)inv.MaxVolume > 9223372036854)
			{
				bCreative = true;
			}
			else
			{
				bCreative = false;
			}

			if (!bCreative)
			{
				//Echo("NCreateive");
				capacity = (double)inv.MaxVolume;
				double dCapacity = defaultCapacity(theContainer);
				if (dCapacity > 0) cargoMult = capacity / dCapacity;
				//					Echo("lContainers="+theContainer.DefinitionDisplayNameText+"'"+inv.MaxVolume.ToString());
			}
			else
			{
				capacity = defaultCapacity(theContainer) * 10;
				cargoMult = 10;
			}
		}
	}
	//	Echo("cargoCapacity=" + capacity.ToString());
	return capacity;
}

double defaultCapacity(IMyTerminalBlock theContainer)
{
    IMyInventory inv = theContainer.GetInventory(0);

	string subtype = theContainer.BlockDefinition.SubtypeId;

	double capacity = (double)inv.MaxVolume;

//Echo("name=" + theContainer.DefinitionDisplayNameText + "\'"+ subtype +"'\n" + "maxvol="+capacity.ToString());

	if (capacity < 999999999) return capacity;

	// else creative; use default 1x capacity
	if (theContainer is IMyCargoContainer)
	{
		// Keen Large Block
		if (subtype.Contains("LargeBlockLargeContainer")) capacity = 421.875008;
		else if (subtype.Contains("LargeBlockSmallContainer")) capacity = 15.625;

		// Keen Small Block
		else if (subtype.Contains("SmallBlockLargeContainer")) capacity = 15.625;
		else if (subtype.Contains("SmallBlockMediumContainer")) capacity = 3.375;
		else if (subtype.Contains("SmallBlockSmallContainer")) capacity = 0.125;

		// Azimuth Large Grid
		else if (subtype.Contains("Azimuth_LargeContainer")) capacity = 7780.8;
		else if (subtype.Contains("Azimuth_MediumLargeContainer")) capacity = 1945.2;

		// Azimuth Small Grid
		else if (subtype.Contains("Azimuth_MediumContainer")) capacity = 1878.6;
		else if (subtype.Contains("Azimuth_SmallContainer")) capacity = 10.125;
	}
	else if (subtype.Contains("SmallBlockDrill")) capacity = 3.375;
	else if (subtype.Contains("LargeBlockDrill")) capacity = 23.4375;
	else if (subtype.Contains("ConnectorMedium")) capacity = 1.152; // sg connector
	else if (subtype.Contains("ConnectorSmall")) capacity =  0.064; // sg ejector
	else if (subtype.Contains("Connector")) capacity =  8.000; // lg connector
	else if (subtype.Contains("LargeShipWelder")) capacity =  15.625; 
	else if (subtype.Contains("LargeShipGrinder")) capacity =  15.625; 
	else if (subtype.Contains("SmallShipWelder")) capacity =  3.375; 
	else if (subtype.Contains("SmallShipGrinder")) capacity =  3.375; 
	else
	{
		Echo("Not cargo:" + theContainer.DefinitionDisplayNameText + ":" + theContainer.BlockDefinition.SubtypeId);
		capacity = 0.125;
	}
	return capacity;

}

#endregion

// SE 1.172
#region tanks
List<IMyTerminalBlock> tankList = new List<IMyTerminalBlock>();
const int iTankOxygen = 1;
const int iTankHydro = 2;
int iHydroTanks = 0;
int iOxygenTanks = 0;
string tanksInit()
{
	tankList.Clear();

	GridTerminalSystem.GetBlocksOfType<IMyGasTank>(tankList, localGridFilter);
//	Echo("tanksinit found" + tankList.Count.ToString() + " Tanks on localgrid");
	iHydroTanks = 0;
	iOxygenTanks = 0;
	for (int i = 0; i < tankList.Count; ++i)
	{
		if (tankType(tankList[i]) == iTankOxygen) iOxygenTanks++;
		else if (tankType(tankList[i]) == iTankHydro) iHydroTanks++;
	}
	return "T" + tankList.Count.ToString("00");
}
double tanksFill(int iTypes = 0xff)
{
	if (tankList.Count < 1) tanksInit();
	if (tankList.Count < 1) return -1;

	double totalLevel = 0;
	int iTanksCount = 0;
	for (int i = 0; i < tankList.Count; ++i)
	{
		int iTankType = tankType(tankList[i]);
		if ((iTankType & iTypes) > 0)
		{
			IMyGasTank tank = tankList[i] as IMyGasTank;
			float tankLevel = tank.FilledRatio;
			totalLevel += tankLevel;
			iTanksCount++;
		}
	}
	if (iTanksCount > 0)
	{
		return totalLevel / iTanksCount;
	}
	else return -1;
}
int tankType(IMyTerminalBlock theBlock)
{
	if (theBlock is IMyGasTank)
	{
		if (theBlock.BlockDefinition.SubtypeId.Contains("Hydro"))
			return iTankHydro;
		else return iTankOxygen;
	}
	return 0;
}

#endregion

#region drills

List <IMyTerminalBlock> drillList = new List <IMyTerminalBlock>();
string drillInit()
{
    List<IMyTerminalBlock> Output = new List<IMyTerminalBlock>();

	drillList.Clear();
	Output = GetTargetBlocks<IMyShipDrill>();
	foreach (var b in Output)
		drillList.Add(b as IMyTerminalBlock);
	return "D" + drillList.Count.ToString("00");
}
#endregion
#region ejectors

List <IMyTerminalBlock> ejectorList = new List <IMyTerminalBlock>();
string ejectorsInit()
{
    List<IMyTerminalBlock> Output = new List<IMyTerminalBlock>();
	ejectorList.Clear();
	Output=GetBlocksContains<IMyShipConnector>("Ejector");
	foreach (var b in Output)
		ejectorList.Add(b as IMyTerminalBlock);
	return "E" + ejectorList.Count.ToString("00");
}
        #endregion

    }
}